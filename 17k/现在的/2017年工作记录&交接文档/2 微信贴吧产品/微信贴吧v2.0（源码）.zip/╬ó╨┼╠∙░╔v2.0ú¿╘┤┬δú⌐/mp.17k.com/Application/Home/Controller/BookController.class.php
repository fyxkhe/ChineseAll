<?php
namespace Home\Controller;
use Think\Controller;
class BookController extends HomeController {
	
	public function index()
	{
		$bookdata=D('Home/booklist')->get_bookByContext();
		$chapterlist=$this->chapterlistdata($bookdata['booksource'],$bookdata['bookid']);
		$this->bookdata=$bookdata;
		$this->chapterlist=$chapterlist;
		foreach($chapterlist as $k=>$v)
		{
			 $this->updatetime=$v['createDate'];
			 break;
		}
		//$this->updatetime=$chapterlist[0]['createDate'];
		//dump($this->bookdata);
		$this->page_title=$bookdata['bookname'].'_最新章节';
		$WebConfig['keywords']=$bookdata['bookname'];
		$WebConfig['describe']=$this->page_title;
		$this->WebConfig=$WebConfig;
		$this->display();
	}
	public function extrabook()
	{
		 $bookdata=D('Home/booklist')->get_extrabookdata();
		 $this->bookdata=$bookdata['data'];
		 
		 $this->page_title='番外集合';//$bookdata['pbook']['bookname'].
		$this->display();
	}
	public function redhat()
	{
		$bookdata=D('Home/booklist')->get_bookByContext();
		redirect('http://h5.17k.com/book/h5/hongbao.action?bookId='.$bookdata['bookid']);
	}
	public function tt($bookid='1001')
	{
		$url='http://h5.17k.com/h5/book/ajaxBookList.k?jsonp=Q.JsonpTmpCallback_9638156634367314&bookId=1198584&page=1&orderType=1&zzaqkey=558839932';
		$data=http_get($url);
		//$html = file_get_contents($url);
		dump($data);
		
	}
	public function chapterlist($type='yys',$bookid='1001',$pageindex=1)
	{
		$bookdata=D('Home/booklist')->get_bookByBookid($type,$bookid);
		$context=D('Home/booklist')->get_book_context($bookid);
		session('name',$context);
		$this->syscontext=D('Home/syscontext')->get_SysContext();
		$chapterlist=$this->chapterlistdata($type,$bookid);
		$this->bookdata=$bookdata;
		$this->chapterlist=$chapterlist; 
		foreach($chapterlist as $k=>$v)
		{
			 $this->updatetime=$v['createDate'];
			 break;
		}
		//$this->updatetime=$chapterlist[0]['createDate'];
		//dump($this->bookdata);
		$this->page_title=$bookdata['bookname'].'_最新章节';
		$this->display();
	}
	public function content($type='yys',$bookid='1001',$chapterid=1)
	{
		if($chapterid==0)
		{
			$this->error('已经是第一章了',U('book/chapterlist',array('bookid'=>$bookid)));return;
		}
		$bookdata=D('Home/booklist')->get_bookByBookid($type,$bookid);
		$chapterdata=M('bookchapter')->cache(true)->where(array('context'=>$bookid,'chapterid'=>$chapterid))->find();
		 if(empty($chapterdata))
		 {
			 $this->error('已经是最后一章了',U('book/chapterlist',array('bookid'=>$bookid)));return;
		 }
		$this->bookdata=$bookdata;
		$this->chapterdata=$chapterdata;
		$this->page_title=$bookdata['bookname'].' '.$chapterdata['title'];
	 
		$this->display();
	}
	public function chapterlistdata($type='17k',$bookid='1198584')
	{
	//获取当天的年份
		$y = date("Y");
		//获取当天的月份  
		$m = date("m");
		//获取当天的号数
		$d = date("d");
		$todayTime= mktime(0,0,0,$m,$d,$y);
		if($type=='17k')
		{
			$data=http_get('http://h5.17k.com/h5/book/ajaxBookList.k?jsonp=Q.JsonpTmpCallback_9638156634367314&bookId='.$bookid.'&page=1&orderType=1&zzaqkey=558839932');
			$data=json_decode($data,true);
			foreach($data['datas'] as $k=>$v)
			{
				if($v['id']=='26583447'||$v['id']=='26583436'||$v['id']=='26583430'||$v['id']=='26583430')
				{
					
					continue;
				}
				$v['createDate']=$v['createDate']/1000;
				if($v['createDate']>=$todayTime)
				{
					$v['color']='red';
				}
				else
				{
					$v['color']='black';
				}
				
				if($v['isVIP']=='N')
				{
					$chapter='chapter';
				}
				else
				{
					$chapter='vipchapter';
				}
				
				$v['url']='http://h5.17k.com/'.$chapter.'/'.$bookid.'/'.$v['id'].'.html' ;
				$chapterlist[$k] =$v;
			} 
		}
		else if($type=='qidian')
		{
			$data=http_get('http://file.authorcrm.com/app/wxcrm/topic/qidian_articleList?bookid='.$bookid.'&pageindex');
			$data=json_decode($data,true);
			$da=array_reverse($data['datas']);
			$ChapterCount=$data['ChapterCount'];
			$data=http_get('http://file.authorcrm.com/app/wxcrm/topic/qidian_articleList?bookid='.$bookid.'&pageindex='.$ChapterCount);
			$data=json_decode($data,true);
			$da=array_reverse($data['datas']);
			$index=0;
			foreach($da as $k=>$v)
			{
				$v['createDate']=time();
				$v['color']='black';
				$chapterlist[$index] =$v;
				$index=$index+1;
			}
			if($index<15&&$ChapterCount-1>0)
			{
				$data=http_get('http://www.authorcrm.com/app/wxcrm/topic/qidian_articleList?bookid='.$bookid.'&pageindex='.$ChapterCount);
				$data=json_decode($data,true);
				$da=array_reverse($data['datas']);
				foreach($da as $k=>$v)
				{
					$v['color']='black';
					$v['createDate']=time();
					$chapterlist[$index] =$v;
					$index=$index+1;
				}
			}
			
		
		}
		else if($type=='yys')
		{
			$data=M('view_bookfanwai')->cache(true)->where(array('bookid'=>$bookid))->select();
			$index=0;
			foreach($data as $k=>$v) 
			{
				$v['createDate']=strtotime($v['cdate']);
				if($v['createDate']>=$todayTime)
				{
					$v['color']='red';
				}
				else
				{
					$v['color']='black';
				}
				$v['url']='http://www.authorcrm.com/project/nbbs/bbs.php?s=/home/index/fanwai/bookid/'.$v['bookid'].'/chapterid/'.$v['chapterid'].'.html'; 
				$v['name']=$v['title'];
				$chapterlist[$index] =$v;
				$index=$index+1;
				 
			}
			 
		}
		else if($type=='weixin')
		{
			$data=M('wxarticle')->cache(true)->where(array('bookid'=>$bookid))->order('ordernum desc')->select();
			$index=0;
			foreach($data as $k=>$v) 
			{
				$v['createDate']=strtotime($v['cdate']);
				if($v['createDate']>=$todayTime)
				{
					$v['color']='red';
				}
				else
				{
					$v['color']='black';
				}
				$v['name']=$v['title'];
				$chapterlist[$index] =$v;
				$index=$index+1;
				 
			}
		}
		return $chapterlist;
		
	}
	

}