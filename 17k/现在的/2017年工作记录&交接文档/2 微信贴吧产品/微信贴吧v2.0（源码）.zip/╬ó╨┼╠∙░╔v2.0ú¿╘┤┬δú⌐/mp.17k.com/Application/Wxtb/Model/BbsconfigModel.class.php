<?php
namespace Wxtb\Model;
use Think\Model;
class BbsconfigModel extends Model {
	public function get_BbsConfig()
	{
		$map=getUidMap();
		$data=$this->field ( true)->cache(true)->where ( $map )->find();
		return  $data;
	}
}