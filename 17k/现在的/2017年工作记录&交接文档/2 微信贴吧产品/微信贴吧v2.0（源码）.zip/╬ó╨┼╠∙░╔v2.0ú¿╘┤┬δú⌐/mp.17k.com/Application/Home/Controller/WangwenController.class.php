<?php
namespace Home\Controller;
use Think\Controller;
class WangwenController extends HomeController {
	
	public function index()
	{
		$this->display();
	}
}