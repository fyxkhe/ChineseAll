<?php
namespace Wechat\Model;
use Think\Model;
class SysuserModel extends Model {
	
    function get_fans($openid)
	{
		$map=array(
		'usertype'=>'weixin',
		'openid'=>$openid
		);
		$data=$this->field ( true)->cache(true)->where ( $map )->find();
		return $data;
	}
	function set_fans($data)
	{
		$moredata=$data;
		unset($moredata['openid']);
		unset($moredata['nickname']);
		unset($moredata['headimgurl']);
		unset($moredata['sex']);
		$data['moredata']=json_encode($moredata);
		$data['context']=C('context');
		$da=$this-> get_fans($data['openid']);
		$data['mdate']=date('Y-m-d H:i:s',time());
		if(empty($da))
		{
			$data['cdate']=date('Y-m-d H:i:s',time());
			$this->data($data)->add();
		}
		else
		{
			$map=array(
			'usertype'=>'weixin',
			'openid'=>$data['openid']
			);
			$this->data($data)->where($map)->save();
		}	
		return $data;
	}
	
	
	
}