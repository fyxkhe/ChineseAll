<?php
namespace Wxtb\Controller;
use Think\Controller;
class IndexController extends BaseController {
    public function index(){
		//dump($this->WebConfig);
        $this->display();
    }
}