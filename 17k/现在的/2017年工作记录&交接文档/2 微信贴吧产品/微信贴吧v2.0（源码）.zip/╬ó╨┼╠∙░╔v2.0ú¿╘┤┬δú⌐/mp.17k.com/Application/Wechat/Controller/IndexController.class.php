<?php
namespace Wechat\Controller;
use Think\Controller;
class IndexController extends Controller {
    public function index(){
        $this->show('wew');
    }
	public function get_access_token($token='gh_c9d7a569bb4c')
	{
		$da= get_access_token($token);
		$data['access_token']=$da;
		$this->ajaxReturn($data);
		 
	}
	public function get_openid($token='gh_c9d7a569bb4c')
	{
		//$openid= get_openid(null,$token);
		$callback = GetCurUrl ();
		$openid= OAuthWeixin ( $callback, $token, true );
		 
		return $openid;
	}
	public function get_fans($token='gh_c9d7a569bb4c',$callback=null,$isrefush=0)
	{
		$openid=$this->get_openid($token);
		if(!empty($callback))
		{
			$callback=urldecode($callback);
			if (strpos ( $callback, '?' ) === false) {
			$callback .= '?';

			} else {

				$callback .= '&'; 
			} 
			$callback=$callback.'openid='.$openid;
			redirect($callback);
		}
		if($isrefush==0)
		{
			$fans=D('Wechat/Sysuser')->get_fans($openid);
		}
		if(empty($fans))
		{
			$fans= getWeixinUserInfo($openid);
			D('Wechat/Sysuser')->set_fans($fans);
		}
		
		return $fans;

	}
	public function get_oldfans($token='gh_c9d7a569bb4c')
	{
		 
	}
	
}