<?php
return array(
	//'配置项'=>'配置值'
	URL_MODEL => 3,
	'__STATIC__'=>__ROOT__ . '/Public/Static',
	'__QQLOGIN__'=>__ROOT__ . '/Public/Static/qqConnect/login/oauth/index.php',
	// 数据库配置
        'DB_TYPE'   => 'mysql', // 数据库类型
        'DB_HOST'   => '60.205.160.18', // 服务器地址
        'DB_NAME'   => 'yys', // 数据库名
        'DB_USER'   => 'root', // 用户名
        'DB_PWD'    => 'xxb199262',  // 密码
        'DB_PORT'   => '3306', // 端口
        'DB_PREFIX' => 'yys_', // 数据库表前缀
		'DB_PARAMS' => array (
				\PDO::ATTR_CASE => \PDO::CASE_NATURAL 
		),
	'HTML_CACHE_ON'=>true,
	'HTML_CACHE_RULES'=>array(
		'book:index'=>array('{$_SERVER.REQUEST_URI|md5}',20),
		'Book:index'=>array('{$_SERVER.REQUEST_URI|md5}',20),
		'weiread:index'=>array('{$_SERVER.REQUEST_URI|md5}',60),
	),
	'DB_SQL_BUILD_CACHE' => true,
	'DB_SQL_BUILD_LENGTH' => 20,
	'DATA_CACHE_TIME'=>60,
);