<?php
namespace Home\Controller;
use Think\Controller;
class WordnewsController extends HomeController {
	
	public function index()
	{
		$this->display();
	}
}