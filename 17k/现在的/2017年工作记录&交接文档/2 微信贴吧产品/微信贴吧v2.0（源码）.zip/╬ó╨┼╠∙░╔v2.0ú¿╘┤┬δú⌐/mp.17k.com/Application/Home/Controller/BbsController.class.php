<?php
namespace Home\Controller;
use Think\Controller;
class BbsController extends HomeController {
	
	function _initialize() 
	{
		if(I('get.name')!=null)
		{
			$name=I('get.name');
		}
		else
		{
			$name='guanqi';
		}
		//$WebConfig=$this->getWebConfig($name,0);
		//$this->WebConfig=$WebConfig;
	}


	public function user($notnull=false)
	{
		$sessionname='wxdata';
		 
		if(F_IS_WEIXIN())
			{
				
				$cookiename='wxcookiedata';
				if(session($cookiename)!=null)
				{
					$wxuser=json_decode(session($cookiename),true) ;
					
				}
				else if(isset($_COOKIE[$cookiename]))
				{
					$wxuser=json_decode($_COOKIE[$cookiename],true) ;  
					//dump($wxuser);// $wxuser;
					 session($cookiename,json_encode( $wxuser)); 
				}
				else if(IS_GET)
				{
					$callback=GetCurUrl();
					$wxuser=OAuthWeixin($callback,C('context'),true);
					//$wxuser=F_GETUSER(C('context'),0 ,0);
					
					session($cookiename,json_encode( $wxuser));
					setcookie($cookiename,json_encode( $wxuser), time()+864000);
					$sql="call nbbs.pro_sys_user_add(
					'gh_c9d7a569bb4c'"
					.",'".$wxuser['openid']
					."','".$wxuser['nickname']
					."','".$wxuser['headimgurl']
					."',".$wxuser['sex'].",'".json_encode($wxuser)."'"
					.",
					@ret,@errmsg)";
					M()->procedure($sql);
				}

			}
			else if($notnull)
			{
				redirect(U('login'));
			}
			else
			{
				
				$cookiename='qqcookiedata';
				if(session($cookiename)!=null)
				{
					$wxuser=json_decode(session($cookiename),true) ; 
				}
				else if(isset($_COOKIE[$cookiename]))
				{
					$wxuser=json_decode($_COOKIE[$cookiename],true) ; 
					//dump($wxuser);// $wxuser;
					 session($cookiename,json_encode( $wxuser));
				}
			}
		 
		return  $wxuser;
	}
	
	function index()
	{
		//$ul=GetCurUrl() ;
		//$userdata=$this->user();
		//dump($userdata);
		$this->display();
	}
	
	
	
	
	
	
}