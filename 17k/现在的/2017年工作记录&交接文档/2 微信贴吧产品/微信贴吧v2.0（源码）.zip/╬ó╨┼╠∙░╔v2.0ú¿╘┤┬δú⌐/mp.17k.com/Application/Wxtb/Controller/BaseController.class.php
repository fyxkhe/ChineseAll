<?php
namespace Wxtb\Controller;
use Think\Controller;
class BaseController extends Controller {
	function _initialize() {
		$this->WebConfig=D('Wxtb/Bbsconfig')->get_Bbsconfig();
	}
	
	
}