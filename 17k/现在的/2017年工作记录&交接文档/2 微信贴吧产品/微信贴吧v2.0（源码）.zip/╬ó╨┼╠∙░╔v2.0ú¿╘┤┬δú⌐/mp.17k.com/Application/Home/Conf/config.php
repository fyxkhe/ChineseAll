<?php
return array(
	//'配置项'=>'配置值'
	'DEFAULT_THEME' => 'default',
	// 模板相关配置
	'TMPL_PARSE_STRING' => array (
			'__STATIC__' => __ROOT__ . '/Public/Static',
			'__COMMON__'=>__ROOT__ . '/Public/Common',
			'__ADDONS__' => __ROOT__ . '/Public/' .APP_PATH. MODULE_NAME . '/Addons',
			'__IMG__' => __ROOT__ . '/Public/' .APP_PATH. MODULE_NAME . '/images',
			'__CSS__' => __ROOT__ . '/Public/' .APP_PATH. MODULE_NAME . '/css',
			'__JS__' => __ROOT__ . '/Public/' .APP_PATH. MODULE_NAME . '/js' 

	), 
		'gh_c9d7a569bb4c'=>array(
		'appid'=>'wx45950bfecd3ade64',
		'secret'=>'363c5fd25b3b69d7d360ef1214ee3f4d'
	),
	'context'=>'gh_c9d7a569bb4c',
	'HTTP_PREFIX'=>'http://', 
);