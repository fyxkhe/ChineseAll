<?php
namespace Home\Model;
use Think\Model;
class WebcategoryModel extends Model {
	
	function get_Webcategory()
	{
		$map=getUidMap();
		$data=$this->field ( true)->cache(true)->where ( $map )->where('status=1')->order('level asc')->select();
		return  $data;
	}
	
}