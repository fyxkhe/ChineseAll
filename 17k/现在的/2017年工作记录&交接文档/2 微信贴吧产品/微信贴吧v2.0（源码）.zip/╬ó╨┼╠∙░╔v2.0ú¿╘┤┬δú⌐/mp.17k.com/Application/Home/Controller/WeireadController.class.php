<?php
namespace Home\Controller;
use Think\Controller;
class WeireadController extends HomeController {
	
	public function index()
	{
		$context=get_uid();
		$map=array(
			'context'=>$context,
			'modelname'=>'weiread/index'
		);
		$model=M('webcategory')->where($map)->find();
		$map='1=0';
		if($model!=null)
		{
			$map=$model['setting'];
		}
		$data=M('view_authorcrm_article',null)->where($map)->limit(0,30)->select();
		 $this->data=$data;
		$this->display();
	}
	public function clickadd($id=0)
	{
		$sql="call pro_au_article_click(
					".$id.",
					@ret,@errmsg)";
		M()->procedure($sql);
		$data['ret']=1;
		$data['errmsg']='操作成功';
		$this->ajaxreturn($data);
	}
}