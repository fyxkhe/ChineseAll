<?php
namespace Home\Controller;
use Think\Controller;
class ShelfController extends HomeController {
	
	public function index()
	{
		$data=M('booklist')->where('pid=0')->select();
		$this->data=$data;
		//dump($data);
		$this->page_title='书架-（功能正在测试）';
		$this->display();
	}
}