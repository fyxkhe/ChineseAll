<?php
return array(
	//'配置项'=>'配置值'
	'gh_c9d7a569bb4c'=>array(
		'appid'=>'wx45950bfecd3ade64',
		'secret'=>'c014925c3ab4d620ca030ce5e895302d'
	),
	'context'=>'gh_c9d7a569bb4c',
	'HTTP_PREFIX'=>'http://',
);