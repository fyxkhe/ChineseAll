<?php
	
function get_access_token_by_apppid($appid, $secret, $update = false) {
	if (empty ( $appid ) || empty ( $secret )) {
		return 0;
	}
	$key = 'access_token_apppid_' . $appid . '_' . $secret;
	$res = S ( $key );
	if ($res !== false && ! $update)
		return $res;
	$url = 'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&secret=' . $secret . '&appid=' . $appid;

	$tempArr = json_decode ( file_get_contents ( $url ), true );

	if (@array_key_exists ( 'access_token', $tempArr )) {

		S ( $key, $tempArr ['access_token'], $tempArr ['expires_in'] );

		return $tempArr ['access_token'];

	} else {

		return 0;

	}

}

function OAuthWeixin($callback, $token = '', $is_return = false) {
 
	$isWeixinBrowser = isWeixinBrowser ();
	if (! $isWeixinBrowser) {
		return false;
	}
	
	$callback = urldecode ( $callback );
	if (strpos ( $callback, '?' ) === false) {
		$callback .= '?';
	} else {
		$callback .= '&';
	}
	if (! empty ( $token ) && strpos ( $token, ':' ) !== false) {
		$arr = explode ( ':', $token );
		$info ['appid'] = $arr [0];
		$info ['secret'] = $arr [1];
	} else {
		$info = get_token_appinfo ( $token );
	}
	if (empty ( $info ['appid'] )) {
		redirect ( $callback . 'openid=-2' );
	}
	$param ['appid'] = $info ['appid'];
	
	if ($_GET ['state'] != 'yys') {
		$param ['redirect_uri'] = $callback;
		$param ['response_type'] = 'code';
		$param ['scope'] = 'snsapi_base';
		$param ['state'] = 'yys';
	
		$url = 'https://open.weixin.qq.com/connect/oauth2/authorize?' . http_build_query ( $param ) . '#wechat_redirect';
		
		redirect ( $url );

	} elseif ($_GET ['state'] == 'yys') {
		
		if (empty ( $_GET ['code'] )) {

			exit ( 'code获取失败' );

		}
	
		

		$param ['code'] = I ( 'code' );

		$param ['grant_type'] = 'authorization_code';

		
		//dump($param);die();
		$param ['secret'] = $info ['secret'];
			$url = 'https://api.weixin.qq.com/sns/oauth2/access_token?' . http_build_query ( $param );
		$content = file_get_contents ( $url );

		$content = json_decode ( $content, true );
		
		if ($is_return) {

			return $content ['openid'];

		} else {
			
			redirect ( $callback . 'openid=' . $content ['openid'] );

		}

	}

}


function get_token_appinfo($token='gh_c9d7a569bb4c')
{
	return C($token);
}

function get_access_token($token = 'gh_c9d7a569bb4c', $update = false) 
{	
	$info = get_token_appinfo ( $token );
	$access_token = get_access_token_by_apppid ( $info ['appid'], $info ['secret'], $update );
	// 自动判断access_token是否已失效，如失效自动获取新的
	if ($update == false) {

		$url = 'https://api.weixin.qq.com/cgi-bin/getcallbackip?access_token=' . $access_token;

		$res = wp_file_get_contents ( $url );

		$res = json_decode ( $res, true );

		if ($res ['errcode'] == '40001') {

			$access_token = get_access_token ( $token, true );

		}

	}
	return $access_token;

}
// php获取当前访问的完整url地址

function GetCurUrl() {

	$url = C('HTTP_PREFIX');

	if ($_SERVER ['SERVER_PORT'] != '80' && $_SERVER ['SERVER_PORT'] != '443') {

		$url .= $_SERVER ['HTTP_HOST'] . ':' . $_SERVER ['SERVER_PORT'] . $_SERVER ['REQUEST_URI'];

	} else {

		$url .= $_SERVER ['HTTP_HOST'] . $_SERVER ['REQUEST_URI'];

	}

	// 兼容后面的参数组装

	if (stripos ( $url, '?' ) === false) {

		$url .= '?t=' . time ();

	}

	return $url;

}

// 获取当前用户的OpenId

function get_openid($openid = NULL,$token='gh_c9d7a569bb4c') {

	
	if ($openid !== NULL && $openid != '-1' && $openid != '-2') {

		session ( 'openid_' . $token, $openid );

	} elseif (! empty ( $_REQUEST ['openid'] ) && $_REQUEST ['openid'] != '-1' && $_REQUEST ['openid'] != '-2') {

		session ( 'openid_' . $token, $_REQUEST ['openid'] );

	}

	//$openid = session ( 'openid_' . $token );
	
	

	$isWeixinBrowser = isWeixinBrowser ();
	
	if ((empty ( $openid ) || $openid == '-1') && $isWeixinBrowser && $_REQUEST ['openid'] != '-2' && IS_GET && ! IS_AJAX) {
		
		$callback = GetCurUrl ();
		
		$openid = OAuthWeixin ( $callback, $token, true );
		
		if ($openid != false && $openid != '-2') {

			session ( 'openid_' . $token, $openid );

		}

	}

	if (empty ( $openid )) {

		return '-1';

	}

	return $openid;

}
function getWeixinUserInfo($openid) {

	
	$access_token = get_access_token ();

	if (empty ( $access_token )) {

		return array ();

	}

	

	$param2 ['access_token'] = $access_token;

	$param2 ['openid'] = $openid;

	$param2 ['lang'] = 'zh_CN';

	

	$url = 'https://api.weixin.qq.com/cgi-bin/user/info?' . http_build_query ( $param2 );

	$content = file_get_contents ( $url );

	$content = json_decode ( $content, true );

	return $content;

}

// 判断是否是在微信浏览器里

function isWeixinBrowser($from = 0) {

	if ((! $from && defined ( 'IN_WEIXIN' ) && IN_WEIXIN) || isset ( $_GET ['is_stree'] ))

		return true;

	

	$agent = $_SERVER ['HTTP_USER_AGENT'];

	if (! strpos ( $agent, "icroMessenger" )) {

		return false;

	}

	return true;

}
// 防超时的file_get_contents改造函数

function wp_file_get_contents($url) {
	$context = stream_context_create ( array (
			'http' => array (

					'timeout' => 30 
			) 

	) ); // 超时时间，单位为秒
	return file_get_contents ( $url, 0, $context );

}