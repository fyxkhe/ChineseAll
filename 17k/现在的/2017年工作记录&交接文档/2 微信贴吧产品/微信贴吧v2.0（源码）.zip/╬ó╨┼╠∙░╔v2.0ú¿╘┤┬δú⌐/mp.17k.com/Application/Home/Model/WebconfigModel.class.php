<?php
namespace Home\Model;
use Think\Model;
class WebconfigModel extends Model {
	
	function get_Webconfig()
	{
		$map=getUidMap();
		$data=$this->field ( true)->cache(true)->where ( $map )->find();
		return  $data;
	}
}