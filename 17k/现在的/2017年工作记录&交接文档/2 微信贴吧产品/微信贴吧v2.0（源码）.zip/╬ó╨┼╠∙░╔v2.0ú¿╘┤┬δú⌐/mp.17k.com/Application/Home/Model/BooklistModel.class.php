<?php
namespace Home\Model;
use Think\Model;
class BooklistModel extends Model {
	
	function get_bookByContext()
	{
		$map= getUidMap();
		$data=$this->field ( true)->where ( $map )->order('level asc')->find();
		return $data;
	}
	function get_extrabookdata()
	{
		$pbook=$this->get_bookByContext();
		$map=array(
			'pid'=>$pbook['id']
		);
		$data=$this->field ( true)->where ( $map )->order('level desc')->select();
		$bookdata['data']=$data;
		$bookdata['pbook']=$pbook;
		return $bookdata;
	}

	function get_book_context($bookid=0)
	{
		$map=array(
			'bookid'=>$bookid
		);
		$data=$this->field ( true)->where ( $map )->find();
		
		if($data==null)
		{
			return '';
		}
		 
		if($data['pid']=='0')
		{
			return $data['context'];
		}
		else
		{
			$map=array(
			'id'=>intval($data['pid'])
			);
			$data=$this->field ( true)->where ( $map )->find();
			return $data['context'];
		}
	}
	function get_bookByBookid($type='17k',$bookid='')
	{
		$map=array(
			'booksource'=>$type,
			'bookid'=>$bookid
		);
		$data=$this->field ( true)->where ( $map )->find();
		return $data;
	}
}