<?php
namespace Home\Controller;
use Think\Controller;
class JokesController extends HomeController {
	
	public function index()
	{	import("Org.Util.simple_html_dom"); 
		$html = file_get_html('http://www.qiushibaike.com/');
		
		 
		$content=$html;
		$content=str_replace('/static/qiushi/','http://www.qiushibaike.com/static/qiushi/',$content);
		$this->content=$content ;
		$this->display();
	}
	public function qiqubaike()
	{
		$this->URL='http://qiqu.uc.cn/?uc_param_str=frpfvedncpssntnwbi&ch=gangxu';
		$this->display();
	}
}