<?php
namespace Home\Model;
use Think\Model;
class SysnotifyModel extends Model {
	public function get_Sysnotify()
	{
		$map=getUidMap();
		$data=$this->field ( true)->cache(true)->where ( $map )->order('level desc,cdate desc')->find();
		return  $data;
	}
	
}