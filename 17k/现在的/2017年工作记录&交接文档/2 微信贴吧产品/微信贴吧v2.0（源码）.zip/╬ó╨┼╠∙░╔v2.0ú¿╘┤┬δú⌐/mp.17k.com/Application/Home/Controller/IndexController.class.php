<?php
namespace Home\Controller;
use Think\Controller;
class IndexController extends HomeController {

	public function index(){
		//dump(U('Book/index'));
		redirect(U('Book/index'));
    }
	public function guanqiwx()
	{
		redirect('https://mp.weixin.qq.com/mp/profile_ext?action=home&__biz=MzAxMzQwMDU0MA==&scene=124#wechat_redirect');
	}
	public function forward($url='')
	{
		if($url=='')
		{
			$url=U('Index/index');
		}
		$this->assign('URL',urldecode($url) );
		$this->display();
	}
	public function url($url)
	{
		redirect($url);
	}
	public function book()
	{
		$this->display('Book/index'); 
	} 
	public function shelf()
	{
		$this->display('Shelf/index');
	}
	public function wangwen()
	{
		$this->display('Wangwen/index');
	}
	public function wordnews()
	{
		$this->display('Wordnews/index');
	}
	public function jokes()
	{
		$this->display('Jokes/index');
	}
}