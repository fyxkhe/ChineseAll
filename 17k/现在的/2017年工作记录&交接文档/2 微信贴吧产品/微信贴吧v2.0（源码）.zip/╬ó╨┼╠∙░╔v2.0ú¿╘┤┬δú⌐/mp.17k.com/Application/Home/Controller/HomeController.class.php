<?php
namespace Home\Controller;
use Think\Controller;
class HomeController extends Controller {
	 
	protected $WEBDATA;
	//初始化操作
	function _initialize() {
		//获取站点全局配置
		$this->syscontext=D('Home/syscontext')->get_SysContext();
		//获取网页配置
		$this->webconfig=D('Home/webconfig')->get_Webconfig();
		//获取header列表
		$this->webcategory=D('Home/webcategory')->get_Webcategory();
		//获取footer列表
		$this->sysnotify=D('Home/sysnotify')->get_Sysnotify();
		//根据ACTION_NAME 设置页面样式
		 
		//
		 
		 
	}
	
}