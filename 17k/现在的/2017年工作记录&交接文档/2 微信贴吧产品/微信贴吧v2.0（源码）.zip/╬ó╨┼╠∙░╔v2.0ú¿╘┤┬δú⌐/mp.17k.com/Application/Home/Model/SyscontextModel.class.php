<?php
namespace Home\Model;
use Think\Model;
class SyscontextModel extends Model {
	
	public function get_SysContext()
	{
		$map=getUidMap();
		$data=$this->field ( true)->cache(true)->where ( $map )->find();
		return  $data;
	}
	
	 
}

