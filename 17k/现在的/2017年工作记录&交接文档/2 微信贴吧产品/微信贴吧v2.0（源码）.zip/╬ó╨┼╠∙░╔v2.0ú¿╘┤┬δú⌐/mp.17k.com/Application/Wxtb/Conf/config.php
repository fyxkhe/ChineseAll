<?php
return array(
		//'配置项'=>'配置值'
	'DEFAULT_THEME' => 'default',
	// 模板相关配置
	'TMPL_PARSE_STRING' => array (
			'__STATIC__' => __ROOT__ . '/Public/Static',
			'__COMMON__'=>__ROOT__ . '/Public/Common',
			'__ADDONS__' => __ROOT__ . '/Public/' .APP_PATH. MODULE_NAME . '/Addons',
			'__IMG__' => __ROOT__ . '/Public/' .APP_PATH. MODULE_NAME . '/images',
			'__CSS__' => __ROOT__ . '/Public/' .APP_PATH. MODULE_NAME . '/css',
			'__JS__' => __ROOT__ . '/Public/' .APP_PATH. MODULE_NAME . '/js' 

	) 
);