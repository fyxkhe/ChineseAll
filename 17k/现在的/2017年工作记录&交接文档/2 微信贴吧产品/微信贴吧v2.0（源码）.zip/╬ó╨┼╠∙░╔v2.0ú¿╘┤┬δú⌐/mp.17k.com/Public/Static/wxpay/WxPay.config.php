<?php
/**
* 
*/

define(APPID , "wxf8b4f85f3a794e77");  //appid
define(APPKEY ,"2Wozy2aksie1puXUBpWD8oZxiD1DfQuEaiC7KcRATv1Ino3mdopKaPGQQ7TtkNySuAmCaDCrw4xhPY5qKTBl7Fzm0RgR3c0WaVYIXZARsxzHV2x7iwPPzOz94dnwPWSn"); //paysign key
define(SIGNTYPE, "sha1"); //method
define(PARTNERKEY,"8934e7d15453e97507ef794cf7b0519d");//通加密串
define(APPSERCERT, "09cb46090e586c724d52f7ec9e60c9f8");

?>