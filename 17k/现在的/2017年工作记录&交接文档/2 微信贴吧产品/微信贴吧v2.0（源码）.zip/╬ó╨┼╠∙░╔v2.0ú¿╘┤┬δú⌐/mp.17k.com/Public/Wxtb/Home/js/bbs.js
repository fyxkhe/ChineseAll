function articleinfo(id)
{
	var tz=$("#manage-"+id);
	$(".action_menu").each(function(){
		var item=$(this);
		var menuid=item.attr("id");
	    if(tz.attr(menuid)=="1")
		{
			item.attr('onclick',menuid+"("+id+")");
			item.show();
		}
		else
		{
			item.attr('dataid','');
			item.hide();
		}
	});
	
	$("#mask").addClass("weui_fade_toggle").show();
	$("#weui_actionsheet").addClass("weui_actionsheet_toggle");
	
}
function cancelmenu()
{
	$("#mask").removeClass("weui_fade_toggle").hide();
	$("#weui_actionsheet").removeClass("weui_actionsheet_toggle");
}