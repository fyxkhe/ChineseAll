<?php
function get_access_token_by_api()
{
	$url='http://mp.authorcrm.com/api.php?s=api&type=fun&method=wx_access_token';
	$tempArr = json_decode ( file_get_contents ( $url ), true );
	return $tempArr;
}
function get_jsapiParams($token='',$callback='')
{
	if($callback=='')
	{
		$callback=GetCurUrl('share'); 
	}
	$url='http://mp.authorcrm.com/api.php?s=api&type=fun&method=jsapi&callback='.urlencode($callback);
	$jsapiParams = json_decode ( file_get_contents ( $url ), true );
	 
	if($token==null)
	{
		$token=DEFAULT_TOKEN;
	}
	$ac=$jsapiParams['access_token'];
	Vendor ( 'jssdk.jssdk' );
	$info=C($token);
	$jssdk = new \JSSDK ( $info ['appid'], '',$ac,$jsapiParams['jsapiTicket']);
	$jsapiParams = $jssdk->GetsignPackage ();
	$jsapiParams['url']=$callback; 
	return $jsapiParams;
}
function get_access_token_by_apppid($appid, $secret, $update = false) {
	if (empty ( $appid ) || empty ( $secret )) {
		return 0;
	}
	$key = 'access_token_apppid_' . $appid . '_' . $secret;
	$res = S ( $key );
	if ($res !== false && ! $update)
		return $res;
	$url = 'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&secret=' . $secret . '&appid=' . $appid;

	$tempArr = json_decode ( file_get_contents ( $url ), true );

	if (@array_key_exists ( 'access_token', $tempArr )) {

		S ( $key, $tempArr ['access_token'], $tempArr ['expires_in'] );

		return $tempArr ['access_token'];

	} else {

		return 0;

	}

}

function OAuthWeixin($callback, $token = '', $is_return = false) {
 
	$isWeixinBrowser = isWeixinBrowser ();
	if (! $isWeixinBrowser) {
		return false;
	}
	
	$callback = urldecode ( $callback );
	if (strpos ( $callback, '?' ) === false) {
		$callback .= '?';
	} else {
		$callback .= '&';
	}
	if (! empty ( $token ) && strpos ( $token, ':' ) !== false) {
		$arr = explode ( ':', $token );
		$info ['appid'] = $arr [0];
		$info ['secret'] = $arr [1];
	} else {
		$info = get_token_appinfo ( $token );
	}
	if (empty ( $info ['appid'] )) {
		redirect ( $callback . 'openid=-2' );
	}
	$param ['appid'] = $info ['appid'];
	
	if ($_GET ['state'] != 'yys') {
		$param ['redirect_uri'] = $callback;
		$param ['response_type'] = 'code';
		$param ['scope'] = 'snsapi_userinfo';//'snsapi_base';
		$param ['state'] = 'yys';
	
		$url = 'https://open.weixin.qq.com/connect/oauth2/authorize?' . http_build_query ( $param ) . '#wechat_redirect';
		
		redirect ( $url );

	} elseif ($_GET ['state'] == 'yys') {
		
		if (empty ( $_GET ['code'] )) {

			exit ( 'code获取失败' );

		}
		$param ['code'] = I ( 'code' );
		$param ['grant_type'] = 'authorization_code';
		//dump($param);die();
		$param ['secret'] = $info ['secret'];
			$url = 'https://api.weixin.qq.com/sns/oauth2/access_token?' . http_build_query ( $param );
		$content = file_get_contents ( $url );
		$content = json_decode ( $content, true );
		if ($is_return) {
			$url='https://api.weixin.qq.com/sns/userinfo?access_token='.$content['access_token'].'&openid='.$content['openid'].'&lang=zh_CN'; 
			$content = file_get_contents ( $url );
			$content = json_decode ( $content, true );
			return $content ;//['openid'];

		} else {
			
			redirect ( $callback . 'openid=' . $content ['openid'] );

		}

	}

}
function get_token_appinfo($token='')
{
	if($token=='')
	{
		$token=DEFAULT_TOKEN;
	}
	return C($token);
}

function get_access_token($token = '', $update = false) 
{	
	$info = get_token_appinfo ( $token );
	$access_token = get_access_token_by_apppid ( $info ['appid'], $info ['secret'], $update );
	// 自动判断access_token是否已失效，如失效自动获取新的
	if ($update == false) {

		$url = 'https://api.weixin.qq.com/cgi-bin/getcallbackip?access_token=' . $access_token;

		$res = wp_file_get_contents ( $url );

		$res = json_decode ( $res, true );

		if ($res ['errcode'] == '40001') {

			$access_token = get_access_token ( $token, true );

		}

	}
	return $access_token;

}
// php获取当前访问的完整url地址

function GetCurUrl($type='') {

	$url = C('HTTP_PREFIX');

	if ($_SERVER ['SERVER_PORT'] != '80' && $_SERVER ['SERVER_PORT'] != '443') {

		$url .= $_SERVER ['HTTP_HOST'] . ':' . $_SERVER ['SERVER_PORT'] . $_SERVER ['REQUEST_URI'];

	} else {

		$url .= $_SERVER ['HTTP_HOST'] . $_SERVER ['REQUEST_URI'];

	}

	// 兼容后面的参数组装
	if($type!='')
	{
		if (stripos ( $url, '?' ) === false) {

		$url .= '?t=' . $type;

		}
		else
		{
			$url .= '&t=' . $type;
		}
	}
	
 
	return $url;

}

// 获取当前用户的OpenId

function get_openid($openid = NULL,$token='') {

	if($token=='')
	{
		$token=DEFAULT_TOKEN;
	}
	if ($openid !== NULL && $openid != '-1' && $openid != '-2') {

		session ( 'openid_' . $token, $openid );

	} elseif (! empty ( $_REQUEST ['openid'] ) && $_REQUEST ['openid'] != '-1' && $_REQUEST ['openid'] != '-2') {

		session ( 'openid_' . $token, $_REQUEST ['openid'] );

	}

	//$openid = session ( 'openid_' . $token );
	
	

	$isWeixinBrowser = isWeixinBrowser ();
	
	if ((empty ( $openid ) || $openid == '-1') && $isWeixinBrowser && $_REQUEST ['openid'] != '-2' && IS_GET && ! IS_AJAX) {
		
		$callback = GetCurUrl ();
		
		$openid = OAuthWeixin ( $callback, $token, false );
		
		if ($openid != false && $openid != '-2') {

			session ( 'openid_' . $token, $openid );

		}

	}

	if (empty ( $openid )) {

		return '-1';

	}

	return $openid;

}
function getWeixinUserInfo($openid) {

	
	$access_token = get_access_token ();

	if (empty ( $access_token )) {

		return array ();

	}

	

	$param2 ['access_token'] = $access_token;

	$param2 ['openid'] = $openid;

	$param2 ['lang'] = 'zh_CN';

	

	$url = 'https://api.weixin.qq.com/cgi-bin/user/info?' . http_build_query ( $param2 );

	$content = file_get_contents ( $url );

	$content = json_decode ( $content, true );

	return $content;

}

// 判断是否是在微信浏览器里

function isWeixinBrowser($from = 0) {

	if ((! $from && defined ( 'IN_WEIXIN' ) && IN_WEIXIN) || isset ( $_GET ['is_stree'] ))

		return true;

	

	$agent = $_SERVER ['HTTP_USER_AGENT'];

	if (! strpos ( $agent, "icroMessenger" )) {

		return false;

	}

	return true;

}
// 防超时的file_get_contents改造函数

function wp_file_get_contents($url) {
	$context = stream_context_create ( array (
			'http' => array (

					'timeout' => 30 
			) 

	) ); // 超时时间，单位为秒
	return file_get_contents ( $url, 0, $context );

}
function set_userinfo($wxuser)
{ 
	
	$cookiename='wxcookiedata';
	session($cookiename,json_encode( $wxuser));
	setcookie($cookiename,json_encode( $wxuser), time()+864000);
	 
}
function get_login_userinfo()
{
	$cookiename='wxcookiedata';
	$wxuser=null;
	 if(session($cookiename)!=null)
	{
		$wxuser=json_decode(session($cookiename),true) ;
	}
	else if(isset($_COOKIE[$cookiename]))
	{
		$wxuser=json_decode($_COOKIE[$cookiename],true) ;  
		session($cookiename,json_encode( $wxuser)); 
	}
	return $wxuser;
}
function loginout()
{
	$cookiename='wxcookiedata'; 
	$_COOKIE[$cookiename]=null;
	session($cookiename,null);
}
function get_userinfo($isrefush=0,$is_return=true,$default='wxlogin',$callback='')
{
	$cookiename='wxcookiedata';
	$wxuser=null;
		 if($isrefush==1)
		 {
			 $_COOKIE[$cookiename]=null;
			 session($cookiename,null);
			 
		 }
		 if(!isWeixinBrowser()&&$default=='wxlogin')
		 {
			 $default='none'; 
		 }
		 
		if(session($cookiename)!=null)
		{
			$wxuser=json_decode(session($cookiename),true) ;
		}
		else if(isset($_COOKIE[$cookiename])) 
		{
			$wxuser=json_decode($_COOKIE[$cookiename],true) ;  
			session($cookiename,json_encode( $wxuser)); 
		}
		else if(!$is_return)
		{
			return null;
		}
		else if(IS_GET)
		{
			if($callback==null)
			{
				$callback=GetCurUrl();
			}
			
			$wxuser=get_novelworld_user($callback,DEFAULT_TOKEN,$default);
			if(!isset($wxuser['openid']))
			{
				return $wxuser; 
			}
			if(isset($wxuser['gender'])&&$wxuser['gender']=='男')
			{
				$wxuser['sex']=1;
			}
			else
			{
				$wxuser['sex']=0;
			}
			if(!isset($wxuser['country']))
			{
				$wxuser['country']='未知';
			}
			if(!isset($wxuser['language']))
			{
				$wxuser['country']='未知';
			}
			if(!isset($wxuser['headimgurl'])&&isset($wxuser['figureurl_qq_1']))
			{
				$wxuser['headimgurl']=$wxuser['figureurl_qq_1'];
			}
			$sql="call pro_bbs_user_add("
			.$isrefush.",'"
			.DEFAULT_TOKEN."'"
			.",'".$wxuser['openid']
			."','".$wxuser['nickname']
			."','".$wxuser['headimgurl']
			."','".$wxuser['sex']
			."','".$wxuser['city']
			."','".$wxuser['province']
			."','".$wxuser['country']
			."','".$wxuser['language']
			."',
			@uid,@mark)";
			$data=M()->procedure($sql);
			$wxuser['uid']=$data[0][0]['uid'];
			$wxuser['mark']=$data[0][0]['mark'];
			session($cookiename,json_encode( $wxuser));
			//cookie($cookiename,json_encode( $wxuser),  time()+864000);  
			setcookie($cookiename,json_encode( $wxuser), time()+864000);
			//dump($data);die;
			//dump($wxuser);die;
		}
		if($wxuser['uid']==null||$wxuser['uid']==0)
		{
			$map['openid']=$wxuser['openid'];
			$uid=M('public_follow')->field('uid')->where($map)->find();
			if($uid!=null)
			{
				$wxuser['uid']=$uid['uid'];
			}
			else
			{
				//dump($wxuser);die;
				$_COOKIE[$cookiename]=null;
				session($cookiename,null);
			}
		}
		else
		{
			setcookie($cookiename,json_encode( $wxuser), time()+864000);
		}
		
		return  $wxuser;
}

function get_novelworld_user($callback,$token,$default='wxlogin')
{
	
	$apicode=I('apicode','none');
	if($apicode=='none')
	{
		if($callback==null)
		{
			$callback=GetCurUrl();
		}
		
		$param['s']='api';
		$param['method']='login'; 
		$param['default']=$default;
		$param['callback']=$callback;
		$param['token']=$token;
		$url='http://mp.authorcrm.com/api.php?'.http_build_query ( $param );
		//dump($url);die;
		redirect($url); 
	}
	else  
	{
		$url='http://mp.authorcrm.com/api.php?s=api&method=getdata&apicode='.$apicode;
		$content = file_get_contents ( $url );  
		
		$data=json_decode($content ,true);
		if($data['status']==1)
		{
			$wxdata=json_decode( $data['data'],true);
			 
		}
		else
		{
			$wxdata['status']=0;
			$wxdata['info']=$data['info'];	
		}
		//dump($wxdata);die;
		return $wxdata;
		//$content = json_decode ( $content, true );
		//dump($content);    
	}
	
	
}
function get_webname()
{   
    $name='';
	if(isset($_SESSION['webname']))
		{
			 $name=$_SESSION['webname'];
		}
		$webname=I('name','');
		if($webname!=null)
		{
			  $name=$webname;
		}
		else if( $name==null)
		{
			  $name=DEFAULT_NAME;
		}
		$_SESSION['webname']= $name;
		return  $name;
}
function weiba_log_add($data)
{
	$data['ctime']=time();
	M('weiba_log')->add($data);
}

function addLog($uid,$eventtype,$data,$result,$token='')
{
	if($uid==null)
	{
		$uid=0;
	}
	if($token==null)
	{
		$token=get_webname();
	}
	$logdata['token']=$token;
	$logdata['uid']=$uid;
	$logdata['eventtype']=$eventtype;
	if(is_array($data))
	{
		$data=json_encode($data);
	}
	$logdata['content']=$data;
	if(is_array($result))
	{
		$result=json_encode($result);
	}
	$logdata['result']=$result;
	$logdata['ctime']=time();
	M('weiba_syslog')->add($logdata);
}
function get_cover_url($cover_id, $field = 'path') {
	if (empty ( $cover_id ))
		return false;
	
	$key = 'Picture_' . $cover_id;
	$picture = S ( $key );
	
	if (! $picture) {
		$map ['status'] = 1;
		$picture = M ( 'Picture' )->where ( $map )->getById ( $cover_id );
		S ( $key, $picture, 86400 );
	}
	$picture ['path']=DEFAULT_FILE.$picture ['path'];
	if (empty ( $picture ))
		return '';

	return empty ( $field ) ? $picture : $picture [$field];
}
function get_users_tag($uid,$weiba_id)
{
	if($uid == null)
	{
		return '';
	}
	$tagkey='user_tag_get_'.$weiba_id.'_'.$uid;
	$content=S($tagkey);
	if($content!=null)
	{
		return $content;
	}
	$content='';
	//获取tagid
	$weiba=D('Home/weiba')->get_weiba($weiba_id);
	
	if($weiba!=null)
	{
		 
		$tagid=$weiba['tagid'];
		if($tagid==null||$tagid<=0)
		{
			$tagid=1;
		}
		$tagdata=M('weiba_score_tag_value')->cache(true)->where(array('tagid'=>$tagid))->select();
		
		$pdata=D('Home/Public')->get_public_by_token($weiba['token']);
		$map['uid']=$uid;
		$map['token']=$pdata['wechat'];
		//获取用户score
		//$weiba_user=M('user')->cache(true)->where($map)->find();
		 
		$weiba_user=M('weiba_users')->where($map)->find();
		 
		if($weiba_user!=null)
		{
		
			$score=$weiba_user['score'];
		}
		else
		{
			unset($map);
			if($uid!=null)
			{
				$map['uid']=$uid;
				$map['token']=$pdata['wechat'];
				$map['mtime']=0;
				$map['post_daycount']=2;
				$id=M('weiba_users')->add($map);
			}
			$score=0;
		}
		
		$tag_value=null;
		foreach($tagdata as $vo)
		{
			if($vo['lscore']<=$score&&$vo['uscore']>$score)
			{
				$tag_value=$vo;
				break;
			}
		}
		if($tag_value!=null)
		{
			if($tag_value['tagurl']==null)
			{
				$tag_value['tagurl']='javascript:void(0);';
			}
			if($tag_value['tagimg']!=null&&$tag_value['tagimg']>0)
			{
				$content.='<a href="'.$tag_value['tagurl'].'"><img src="'.get_cover_url($tag_value['tagimg']).'" alt="'.$tag_value['tagtitle'].'" title="'.$tag_value['tagtitle'].'"></a>';
			}
			else
			{
				$content.='<a href="'.$tag_value['tagurl'].'"><span class="color-block f-11rem" style="background: #5bc3ff;height:15px;">'.$tag_value['tagtitle'].'</span></a>';
			}
			 
		}
		/*
		unset($map);
		$map['weiba_id']=$weiba_id;
		$map['uid']=$uid;
		$utag=M('weiba_users_tag')->where($map)->find();
		if($utag!=null)
		{
			$content.='&nbsp;';
			if($utag['tagimg']!=null&&$utag['tagimg']>0)
			{
				$img=get_cover_url($utag['tagimg']);
				$content.='<img src="'.$img.'" alt="'.$utag['tagname'].'" title="用户认证">';
			}
			else
			{
				$content.='<span class="color-block f-11rem" style="height:15px;background:'.$utag['tagstyle'].';">'.$utag['tagname'].'</span>'; 
			}
			
		}*/
		unset($map);
		$map['uid']=$uid;
		$map['token']=$weiba['token'];
		$map['status']=1;
		$utag=M('weiba_users_tag_value')->where($map)->limit(0,4)->order('mtime desc')->cache(true)->select();
		
		if(!empty($utag))
		{
			foreach($utag as $li)
			{
				unset($map2);
				$map2['id']=$li['tagid'];
				$utag2=M('weiba_users_tag')->where($map2)->cache(true)->find();
				if($utag2!=null)
				{
					if($utag2['tagurl']==null)
					{
						$utag2['tagurl']='javascript:void(0);';
					}
					$content.='&nbsp;';
					if($utag2['tagimg']!=null&&$utag2['tagimg']>0)
					{
						$img=get_cover_url($utag2['tagimg']);
						$content.='<a href="'.$utag2['tagurl'].'"><img src="'.$img.'" alt="'.$utag2['tagname'].'" title="用户认证"></a>';
					}
					else
					{
						$content.='<a href="'.$utag2['tagurl'].'"><span class="color-block f-11rem" style="height:15px;background:'.$utag2['tagstyle'].';">'.$utag2['tagname'].'</span></a>'; 
					}
					
				}
			}
		}
		//$content.='<img src="http://img.17k.com/user/new/images/icon_author.png" alt="作者" title="用户认证">';
	}
	
	S($tagkey,$content,400); 
	//S(null);
	return $content;
	
	
	 
}
 
 function get_login($name,$login_tip='用户未登录',$login_url=null,$login_btn='点此登陆')
	{
		 $url= C('HTTP_PREFIX');
		if ($_SERVER ['SERVER_PORT'] != '80' && $_SERVER ['SERVER_PORT'] != '443') {

			$url .= $_SERVER ['HTTP_HOST'] . ':' . $_SERVER ['SERVER_PORT'];

		} else {

			$url .= $_SERVER ['HTTP_HOST'] ;

		}
		if($login_url==null)
		{
			$login_url=GetCurUrl();
		}
		//$login_url=$login_url; 
		$login_url=U('index/login',array('name'=>$name,'backurl'=>urlencode($login_url)));
		if($login_tip==null)
		{
			return $login_url;
		}
		else if($login_tip=='none')
		{
			$login_tip='';
		}
		else
		{
			$login_tip .='<br>';
		}
		
		return $login_tip.'<a style="color:blue;" href="'.$login_url.'">'.$login_btn.'</a>';
	} 

	function addUserScore($name,$uid,$score,$weiba_id=0)
	{
		if($uid==null||$uid==0)
		{
			return;
		}
		$map['token']=$name;
		$map['uid']=$uid;
		$userdata=M('weiba_users')->where($map)->find();
		$mtime=time();
		if($userdata==null)
		{
			unset($map);
			$map['token']=$name;
			$map['uid']=$uid;
			$map['mtime']=0;
			$map['post_daycount']=1;
			$map['score']=$score;
			$id=M('weiba_users')->add($map);
			//$userdata=M('weiba_users')->where($map)->find();
		}
		else
		{
			$mtime=$userdata['mtime'];
		}
		//一天计算一次
		unset($map);
		$map['token']=$name;
		$map['uid']=$uid;
		if($weiba_id>0)
		{
		    $td=getToday(time());
			$mmtime=getToday($mtime);
			if($td>$mmtime)
			{
				
				$post_count=M('weiba_post')->where('weiba_id='.$weiba_id.' and post_uid='.$uid.' and post_time>'.$mtime)->count();
				$reply_count=M('weiba_reply')->where('weiba_id='.$weiba_id.' and uid='.$uid.' and ctime>'.$mtime)->count();
				$score+=$post_count;
				$score+=$reply_count;
				$mmap['mtime']=time();
				$userdata=M('weiba_users')->where($map)->save($mmap);
				
			}
			if($score>20)
			{
				$score=20;
			}
			unset($data);
			$data['weiba_id']=$weiba_id;
			$data['uid']=$uid;
			$data['to_uid']=$score;
			$data['type']='addUserScore';
			$data['content']='添加积分';
			$data['ctime']=time();
			M('weiba_log')->add($data);
		}
		if($score>20)
		{
			$score=20;
		}
		M('weiba_users')->where($map)->setInc('score',$score);
	}
	
function get_last_url($bkurl='')
{
	if($bkurl==null)
	{
		$bkurl=U('index/index');
	}
	$key='get_last_url';
	if(session($key)!=null)
	{
		$bkurl=session($key);
	}
	
	session($key,$_SERVER['HTTP_REFERER']);
	return $bkurl;
}
function get_help($type)
{
	$help['url']='';
	$help['title']='';
	if($type=='17k')
	{
		$help['title']='*充值、阅读有问题戳这里';
		$help['url']=U('index/content',array('id'=>12625));
	}
	
	return $help;
}
function send_toBaidu($url=null)
{
	try
	{
		if($url==null)
		{
			$url=GetCurUrl();
		}
		$urls = array(
			$url,
			'http://mp.17k.com/'
		
		);
		$api = 'http://data.zz.baidu.com/urls?site=mp.17k.com&token=RDlxwdkJZnlVc84O';
		$ch = curl_init();
		$options =  array(
			CURLOPT_URL => $api,
			CURLOPT_POST => true,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_POSTFIELDS => implode("\n", $urls),
			CURLOPT_HTTPHEADER => array('Content-Type: text/plain'),
		);
		curl_setopt_array($ch, $options);
		$result = curl_exec($ch);
		$result=json_decode($result,true);
		$result['url']=$url;
		$result=json_encode($result);
		return $result;
	}
	catch(\Exception $e){  
			return $e;  
	} 
}
function get_ico($name='',$group='common')
{
	$skey=$group.'_'.$name;
	$content=S($skey);
	if($content==null)
	{
		$data=M('weiba_ico')->where(array('name'=>$name,'group'=>$group))->find();
		$content=$data['content'];
		$content=str_replace("__COMMON__",C('TMPL_PARSE_STRING.__COMMON__'),$content);
		S($skey,$content,2000);
	}
	if($content==null)
	{
		$content='';
	}
	
	return $content;
}
function post_limit($token='none',$uid=0,$type='post',$limit_time=1,$gtime=60)
{
	$host=I('server.REMOTE_ADDR');
	$htime=S($type.'_'.$uid);
	if($htime==null)
	{
		$htime=0;
	}
	$htime++;
	S($type.'_'.$uid,$htime,$gtime);
	if($htime==$limit_time||$htime%($limit_time*10)==0)
	{
		$data['eventtype']=$type.'_limit';
		$data['token']=$token;
		$data['uid']=$uid;
		$data['content']='IP ['.$host.']'.$gtime.'秒内操作次数超过'.$limit_time.'次,累积访问'.$htime.'次';
		$data['result']='用户操作太频繁，被禁止操作。';
		$data['ctime']=time();
		M('weiba_syslog')->add($data);
	}
	if($htime>$limit_time)
	{
		return false;
		 
	}
	else
	{
		return true;
	}
}
function add_gift($token='')
{
	$userdata=get_userinfo(0,false);
	$ct=false;
	if($userdata!=null)
	{
		
	}
}
 
function check_gift($token='')
{
	$map['token']=$token;
	$map['tagname']='gift';
	$gifttag=M('weiba_users_tag')->where($map)->cache(true)->find();
	if($gifttag!=null)
	{
		$gifttag['url']=U('index/game_url',array('name'=>$token,'type'=>'gift'));
	}
	return $gifttag;
	
	
}
 function n_encrypt($string,$operation,$key='abckey')
 {
  $key=md5($key);
  $key_length=strlen($key);
  $string=$operation=='D'?base64_decode($string):substr(md5($string.$key),0,8).$string;
  $string_length=strlen($string);
  $rndkey=$box=array();
  $result='';
  for($i=0;$i<=255;$i++)
  {
   $rndkey[$i]=ord($key[$i%$key_length]);
   $box[$i]=$i;
  }
  for($j=$i=0;$i<256;$i++)
  {
   $j=($j+$box[$i]+$rndkey[$i])%256;
   $tmp=$box[$i];
   $box[$i]=$box[$j];
   $box[$j]=$tmp;
  }
  for($a=$j=$i=0;$i<$string_length;$i++)
  {
   $a=($a+1)%256;
   $j=($j+$box[$a])%256;
   $tmp=$box[$a];
   $box[$a]=$box[$j];
   $box[$j]=$tmp;
   $result.=chr(ord($string[$i])^($box[($box[$a]+$box[$j])%256]));
  }
  if($operation=='D')
  {
   if(substr($result,0,8)==substr(md5(substr($result,8).$key),0,8))
   {
    return substr($result,8);
   }
   else
   {
    return'';
   }
  }
  else
  {
   return str_replace('=','',base64_encode($result));
  }
 }
function load_limit($limitcount=10,$jump_url='',$key=null,$userkey=null)
{
	if($jump_url!=null)
	{
		$url=$jump_url;
	}
	else
	{
		$url=GetCurUrl();
	}
	//dump($url); 
	
	if(stripos($url,"&s_id")!== false){
		$s_id=str_replace('&s_id=','',strstr($url,"&s_id="));
		$url=strstr($url,"&s_id",true); 
	}
	else if(stripos($url,"?s_id")!== false){
		$s_id=str_replace('?s_id=','',strstr($url,"?s_id="));
		$url=strstr($url,"?s_id",true); 
	}
	else
	{
		$s_id='none';
	}
	//dump($url); 
	if($key==null)
	{
		$key=md5($url);
	}
	$ntime=time();
	$data=S($key);
	//dump($data);
	$host=I('server.REMOTE_ADDR');
	$user_gtime=null;
	if($s_id!='none')
	{
		$user_gtime= n_encrypt(urldecode($s_id),'D','load_limit');
		$user_gtime=intval($user_gtime);
	}
	if($user_gtime!=null)
	{
		if($user_gtime>$ntime)
		{
			if($data!=null)
			{
				$data['count']--;
				if($data['count']<0)
				{
					$data['count']=0;
				}
				S($key,$data,300);
			}
			//dump('b:'.($user_gtime-$ntime));
			return null;
		}
	}
	
	if($data==null)
	{
		$data['stime']=$ntime;
		$data['count']=0;
	}
	if($userkey==null)
	{
		$userkey=$key.'_'.$host;
	}
	 //dump($userkey);
	if(S($userkey)==null)
	{
		$addcount=1;
	}
	else
	{
		$addcount=0;
	}
	$data['count']=$data['count']+$addcount;	
	$ct=$data['count'];
	$stime=$data['stime'];
	$ecount=($ntime-$stime)*$limitcount;
	//dump('ecount:'.$ecount);
	if($ecount>$ct)
	{
		$data['count']=0;
		$data['stime']=$ntime;
		$jump_time=0;
		
	}
	else
	{
		//排时间
		$jump_time=intval((($ct-$ecount)/$limitcount)+1);
	}
	S($key,$data,300);
	$user_gtime=$ntime+$jump_time+5;
	$s_id_url='s_id='.urlencode(n_encrypt($user_gtime,'E','load_limit'));
	if(stripos($url,"?")!== false){
		$url=$url.'&'.$s_id_url;
	}
	else
	{
		$url=$url.'?'.$s_id_url;
	}

	$jump_data['jump_time']=$jump_time;
	$jump_data['count']=$ct-$ecount;
	$jump_data['url']=$url;
	$jump_data['limitcount']=$limitcount;
	$jump_data['host']=$host;
	S($userkey,'add',$jump_time+10);
	if($jump_time<1)
	{
		//dump($jump_time);
		return null;
	}

	return $jump_data;
	
	
}
function o_load_limit($limitcount=10,$jump_url='',$key=null,$userkey=null)
{
	if($jump_url!=null)
	{
		$url=$jump_url;
	}
	else
	{
		$url=GetCurUrl();
	}
	if($key==null)
	{
		$key=md5($url);
	}
	$ntime=time();
	$data=S($key);
	$host=I('server.REMOTE_ADDR');
	//dump('host:'.$host);
	if($userkey==null)
	{
		$userkey=$key.'_'.$host;
	}
	//dump($userkey);
	$user_gtime=S($userkey);
	//dump($data);
	//dump('a:'.$user_gtime);
	if($user_gtime!=null)
	{
		if(I('istest',0)==1)
		{
			S($userkey,null);
		}
		//cookie($userkey,null);
		if($user_gtime>$ntime)
		{
			if($data!=null)
			{
				$data['count']--;
				if($data['count']<0)
				{
					$data['count']=0;
				}
				S($key,$data,300);
			}
			//dump('b:'.($user_gtime-$ntime));
			return null;
			
		}
	}
	if($data==null)
	{
		$data['stime']=$ntime;
		$data['count']=0;
	}
	$data['count']++;
	$ct=$data['count'];
	$stime=$data['stime'];
	$ecount=($ntime-$stime)*$limitcount;
	if($ecount>$ct)
	{
		$data['count']=0;
		$data['stime']=$ntime;
		$jump_time=0;
	}
	else
	{
		//排时间
		$jump_time=(($ct-$ecount)/$limitcount)+1;
	}
	S($key,$data,300);
	$jump_data['jump_time']=$jump_time;
	$jump_data['count']=$ct-$ecount;
	$jump_data['url']=$url;
	$jump_data['limitcount']=$limitcount;
	$jump_data['host']=$host;
	S($userkey,$ntime+$jump_time+5,$ntime+$jump_time+10); 
	//dump('c:'.$jump_time);
	
	if($jump_time<2)
	{
		return null;
	}
	return $jump_data;
}