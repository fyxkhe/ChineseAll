<?php
namespace Home\Controller;
use Think\Controller;
class ApiController extends Controller {
	
	function littleapp()
	{
		$data=M('weiba_book')->where(array('isreadpage'=>1))->select();
		$this->show(json_encode($data));
		 
	}
	
	
	function get_supfans($name='',$uid=-1,$weiba_id=0)
	{
		$mydata=null;
		$map['token']=$name;
		$map['status']=1;
		$data=M('weiba_tag_view')->where($map)->order('click_count desc,score desc')->cache(true)->limit(0,100)->select();
		$allcount=M('weiba_tag_view')->where($map)->count();
		foreach($data as &$da)
		{
			$da['nickname']=str_urldecode_trim($da['nickname']);
			if($da['score']==null)
			{
				$da['score']=0;
			}
			if($da['click_count']==null)
			{
				$da['click_count']=0;
			}
			$da['status']='已通过';
			$da['usertag']=get_users_tag($da['uid'],$weiba_id);
			if($uid==$da['uid'])
			{
				$mydata=$da;
			}
		}
		if($mydata==null&&$uid>0)
		{
			unset($map);
			$map['token']=$name;
			$map['uid']=$uid;
			$mydata=M('weiba_tag_view')->where($map)->cache(true)->find();
			if($mydata!=null)
			{	$mydata['nickname']=str_urldecode_trim($mydata['nickname']);
				if($mydata['score']==null)
				{
					$mydata['score']=0;
				}
				if($mydata['click_count']==null)
				{
					$mydata['click_count']=0;
				}
				$mydata['usertag']=get_users_tag($mydata['uid'],$weiba_id);
				if($mydata['status']==-1)
				{
					$mydata['usertag'].=$da['tagname'].'&nbsp;<a href="'.$da['tagvalueurl'].'">(未通过)</a>';;
				}
				else if($mydata['status']==0)
				{
					$mydata['usertag'].=$da['tagname'].'&nbsp;<a href="'.$da['tagvalueurl'].'">(待审核)</a>';;
				}
			}
			else
			{
				unset($map);
				$map['token']=$name;
				$map['uid']=$uid;
				$mydata=M('weiba_users')->where($map)->find();
				 
				$mydata['usertag']=get_users_tag($mydata['uid'],$weiba_id);
				if(count($data)>0)
				{
					$mydata['usertag'].='<br><a href="'.$data[0]['tagurl'].'">(你不在榜单中，点此申请)</a>';;
				}
			}
		}
		$mydata['color']='red';
		$list_data=null;
		$i=0;
		$list_data[$i]=$mydata;
		foreach($data as $li)
		{
			$i++;
			$list_data[$i]=$li;
		}
		$ret['count']=$allcount;
		$ret['data']=$list_data;
		return $ret;	 
	 
	}
	function get_active($name='',$uid=-1,$weiba_id=0)
	{
		if($name==null)
		{
			$name=get_webname();
		}
		if($weiba_id==0)
		{
			$bbs=D('Home/weiba')->get_bbs($name,'bbs');
			$weiba_id=$bbs['id'];
		}
		$map['token']=$name;
		$data=M('weiba_users_view')->where($map)->order('click_count desc,score desc,uid asc')->cache(true)->limit(0,100)->select();
		$allcount=M('weiba_users')->where($map)->cache(true)->count();
		
		$index=0;
		$myindex=0;
		$mydata=null;
		foreach($data as &$da)
		{
			$index++;
			$da['index']=$index;
			$da['usertag']=get_users_tag($da['uid'],$weiba_id);
			$da['nickname']=str_urldecode_trim($da['nickname']); 
			if($da['uid']==$uid)
			{
				$mydata=$da;
			}
		}
		if($mydata==null&&$uid>0)
		{
			$map['uid']=$uid;
			$mydata=M('weiba_users_view')->where($map)->cache(true)->find();
			if($mydata!=null)
			{
				$cc=$mydata['click_count'];
				$sc=$mydata['score'];
				$sql='token="'.$name.'" and (click_count>'.$cc.' or (click_count='.$cc.' and score>'.$sc.') or (click_count='.$cc.' and score='.$sc.' and uid<'.$uid.'))';
				$myindex=M('weiba_users_view')->where($sql)->count();
				$mydata['index']=$myindex;
			}
			
		}
		$mydata['color']='red';
		$list_data=null;
		$i=0;
		$list_data[$i]=$mydata;
		foreach($data as $li)
		{
			$i++;
			$list_data[$i]=$li;
		}
		$ret['count']=$allcount;
		$ret['data']=$list_data;
		return $ret;	 
		 
		
	}
	function get_singin($name='',$uid=-1,$weiba_id=0)
	{
		if($name==null)
		{
			$name=get_webname();
		}
		if($uid>0)
		{
			$singdata=D('Home/WeibaUsers')->SingIn($uid,$name);
		}
		else
		{
			$singdata=null;
		}
		$today=getToday(time());
		$singin_key='SingIn_'.$name.'_'.$today;
		$singtop=D('Home/WeibaUsers')->get_singin_top($name,$today,100);
		$singcount=D('Home/WeibaUsers')->get_singin_count($name,$today);
		$top=0;
		foreach($singtop as &$li)
		{
			$ljts=M('signin_log')->where(array('uid'=>$li['uid'],'token'=>$li['token']))->count();
			$sdata=json_decode($li['mark'],true);
			$top++;
			//$top=intval($sdata['top'],0);
			$li['index']=$top;
			$li['singin_time']=date('H:i:s',$sdata['singin_time']);
			$li['nickname']=str_urldecode_trim($li['nickname']); 
			$li['usertag']=get_users_tag($li['uid'],$weiba_id);
			$li['singin_day']=$ljts;
			
			$li['singin_day_lx']=$sdata['singin_day'];
			if($uid==$li['uid'])
			{
				 $singdata=$li;
			}
		}
		$singdata['color']='red';
		$list_data=null;
		$i=0;
		$list_data[$i]=$singdata;
		foreach($singtop as $d)
		{
			
			$i++;
			$list_data[$i]=$d;
			
		}
		$ret['count']=$singcount;
		$ret['data']=$list_data;
		return $ret;	 
		
	}
	public function get_17k_book($bookid='')
	{
		$data=http_get('http://h5.17k.com/h5/book/ajaxBookList.k?jsonp=Q.JsonpTmpCallback_9638156634367314&bookId='.$bookid.'&page=1&orderType=1&zzaqkey=558839932');
		//return $data; 
		$this->show(json_encode($data));
		
	}
	public function get_17k($bookid='')
	{
		$url='http://h5.17k.com/h5/book/ajaxBookList.k?jsonp=Q.JsonpTmpCallback_9638156634367314&bookId='.$bookid.'&page=1&orderType=1&zzaqkey=558839932';
		 
		redirect($url); 
		  
	}
	
	public function check_login()
	{
		$userdata=get_userinfo(0,true,'wxlogin');
		if($userdata!=null)
		{
			dump($userdata['nickname']);
		}
		else
		{
			dump('未登录');
		}
	}
	public function index()
	{
		dump('tag');
	}
	public function ueditor()
	{
		$data = new \Org\Util\Ueditor();
		echo $data->output();
	}
	public function get_tag($weiba_id,$uid)
	{
		$tagkey='users_tag_get_'.$weiba_id.'_'.$uid;
		//$content=S($tagkey);
		if($content!=null)
		{
			return $content;
		}
		$content='';
		//获取tagid
		$weiba=D('Home/weiba')->get_weiba($weiba_id);
		
		if($weiba!=null)
		{
			 
			$tagid=$weiba['tagid'];
			if($tagid==null)
			{
				$tagid=1;
			}
			$tagdata=M('weiba_score_tag_value')->cache(true)->where(array('tagid'=>$tagid))->select();
			
			$pdata=D('Home/Public')->get_public_by_token($weiba['token']);
			$map['uid']=$uid;
			$map['token']=$pdata['wechat'];
			//获取用户score
			//$weiba_user=M('user')->cache(true)->where($map)->find();
			 
			$weiba_user=M('weiba_users')->cache(true)->where($map)->find();
			 
			if($weiba_user!=null)
			{
				
				
				$tday=getToday(time());
				$mtime=getToday($weiba_user['mtime']);
				if($tday!=$mtime)
				{
					$sdata['mtime']=time();
					
					//计算发了多少帖子，回复多少帖子
					$post_count=M('weiba_post')->where('weiba_id='.$weiba_id.' and post_uid='.$uid.' and post_time>'.$weiba_user['mtime'])->count();
					$reply_count=M('weiba_reply')->where('weiba_id='.$weiba_id.' and uid='.$uid.' and ctime>'.$weiba_user['mtime'])->count();
					M('weiba_users')->where($map)->save($sdata);
					M('weiba_users')->where($map)->setInc('score',$post_count*3+$reply_count);
					$weiba_user['score']=$weiba_user['score']+$post_count*3+$reply_count;
					
				}
			
				$score=$weiba_user['score'];
			}
			else
			{
				$map['mtime']=time();
				M('weiba_users')->add($map);
				$score=0;
			}
			
			$tag_value=null;
			foreach($tagdata as $vo)
			{
				if($vo['lscore']<=$score&&$vo['uscore']>$score)
				{
					$tag_value=$vo;
					break;
				}
			}
			if($tag_value!=null)
			{
				if($tag_value['tagimg']!=null&&$tag_value['tagimg']>0)
				{
					$content.='<img src="'.get_cover_url($tag_value['tagimg']).'" alt="'.$tag_value['tagtitle'].'" title="'.$tag_value['tagtitle'].'">';
				}
				else
				{
					$content.='<span class="color-block f-11rem" style="background: #5bc3ff;height:15px;">'.$tag_value['tagtitle'].'</span>';
				}
			}
	}
	
	//$content.='<img src="http://img.17k.com/user/new/images/icon_author.png" alt="作者" title="用户认证">';
	//S($tagkey,$content,3600); 
	//S(null);
	$this->show($content);
	//return $content;
	
	
	}
	public function  t()
	{
		$tag= get_users_tag(888,4);
		$map['weiba_id']=4;
		$map['uid']=888;
		$utag=M('weiba_users_tag')->where($map)->find();
		if($utag!=null)
		{
			if($utag['tagstyle']=='users'&&$utag['tagimg']!=null)
			{
				$img=get_cover_url($utag['tagimg']);
				$content.='<img src="'.$img.'" alt="'.$utag['tagname'].'" title="用户认证">';
			}
			
		}
		dump($tag);
	}
	public function signin($name='')
	{
		$userdata=get_userinfo();
		if(IS_POST)
		{
			if(!$userdata)
			{
				$data['ret']=0;
				$data['errmsg']=get_login($name,'用户未登录',U('index/index',array('name'=>$name)));
				$this->ajaxReturn($data);
			}
		}
		if($name==null)
		{
			$name=get_webname();
		}
		$singdata=D('Home/WeibaUsers')->SingIn($userdata['uid'],$name);
		$today=getToday(time());
		$singin_key='SingIn_'.$name.'_'.$today;
		$singtop=D('Home/WeibaUsers')->get_singin_top($name,$today,10);
		$singcount=D('Home/WeibaUsers')->get_singin_count($name,$today);
		$singdata=json_decode($singdata,true);
		$this->singdata= $singdata;
		$this->singtop=$singtop;
		if(IS_POST)
		{
			$content='';
			$content.='<table class="table table-striped">';
			$content.='<caption>'.date('Y年m月d日',time()).'签到排行榜</caption> <thead> <th>排名</th><th>昵称</th><th>签到时间</th><th>累积签到</th></thead> <tbody>';
			$usertop=intval($singdata['top'],0);
			foreach($singtop as $li)
			{
				$ljts=M('signin_log')->where(array('uid'=>$li['uid'],'token'=>$li['token']))->count();
				$sdata=json_decode($li['mark'],true);
				$top=intval($sdata['top'],0);
				$tdstring='<tr><td>'.$sdata['top'].'</td><td>'.str_get_describe($li['nickname'],'',10).'</td><td>'.date('H:i:s',$sdata['singin_time']).'</td><td>'.$ljts.'</td></tr>';
				if($usertop==$top)
				{
					$tdstring=str_replace('<td>','<td style= "color:red">',$tdstring);
				}
				$content.=$tdstring;
			}
			if($usertop>count($singtop))
			{
				$ljts=M('signin_log')->where(array('uid'=>$userdata['uid'],'token'=>$name))->count();
				$content.='<tr><td>...</td><td>...</td><td>...</td><td>...</td></tr>';
				$content.='<tr><td style= "color:red">'.$singdata['top'].'</td><td style= "color:red">'.str_get_describe($userdata['nickname'],'',6).'</td><td style= "color:red">'.date('H:i:s',$singdata['singin_time']).'</td><td style= "color:red">'.$ljts.'</td></tr>';
			}
			$content.=' </tbody></table>';	
			$content.='<p>(总计签到:'.$singcount.'人  )</p>';
			$content.='<p><a style="color:blue" href="'.U('index/bangdan',array('name'=>$name,'type'=>'singin')).'">查看更多榜单</a></p>';
			//<p>签到升级，原签到数据清空，敬请谅解</p>
			$data['ret']=1;
			$data['errmsg']=$content;
			$this->ajaxReturn($data);
			
		}
		   
		
		
		 
		//$this->display();
		
	}
}