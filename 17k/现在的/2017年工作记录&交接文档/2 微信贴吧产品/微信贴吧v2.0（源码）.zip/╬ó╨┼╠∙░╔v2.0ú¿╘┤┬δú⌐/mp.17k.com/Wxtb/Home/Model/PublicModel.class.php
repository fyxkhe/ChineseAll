<?php
namespace Home\Model;
use Think\Model;
class PublicModel extends Model {
	function get_data($name='')
	{
		if($name=='')
		{
			$name=get_webname();
		}
		$map['wechat']=$name;
		$data=$this->field ( true)->cache(true)->where ( $map )->find();
		return  $data;
		
	}
	function get_public_by_token($token)
	{
		$map['token']=$token;
		$data=$this->field ( true)->cache(true)->where ( $map )->find();
		return $data;
	}
	function publicdata()
	{
		$data=$this->field ( true)->cache(true)->select();
		foreach ( $data as $li ) {
			$pdata[$li['token']]=$li;
			$pdata[$li['wechat']]=$li;
		}
		return $pdata;
	}
	
	
}