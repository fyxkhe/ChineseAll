<?php
namespace Home\Controller;
use Think\Controller;
class EmptyController extends Controller {
	
	public function index()
	{
		dump('tag11');
	}
	function Uploads()
	{
		dump('555');
	}
	 public function _empty(){
        
		dump('22');
         
    }
}