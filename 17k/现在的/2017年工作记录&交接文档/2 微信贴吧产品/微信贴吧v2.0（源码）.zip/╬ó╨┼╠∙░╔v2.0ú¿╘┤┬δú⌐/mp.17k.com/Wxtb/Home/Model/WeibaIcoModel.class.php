<?php
namespace Home\Model;
use Think\Model; 
class WeibaIcoModel extends Model {
	function get_ico($type)
	{
		 
		return $data;
	}
	
}