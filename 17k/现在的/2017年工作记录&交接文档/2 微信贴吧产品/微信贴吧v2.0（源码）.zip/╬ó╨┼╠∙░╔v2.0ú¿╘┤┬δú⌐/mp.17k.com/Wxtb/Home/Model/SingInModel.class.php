<?php
namespace Home\Model;
use Think\Model;
class SingInModel extends Model {
	
	
}