<?php
function hook($hook, $params = array()) {

	\Think\Hook::listen ( $hook, $params );

}
 function http_get($url){
	$oCurl = curl_init();
	if(stripos($url,"https://")!==FALSE){
		curl_setopt($oCurl, CURLOPT_SSL_VERIFYPEER, FALSE);
		curl_setopt($oCurl, CURLOPT_SSL_VERIFYHOST, FALSE);
		curl_setopt($oCurl, CURLOPT_SSLVERSION, 1); //CURL_SSLVERSION_TLSv1
	}
	curl_setopt($oCurl, CURLOPT_URL, $url);
	curl_setopt($oCurl, CURLOPT_RETURNTRANSFER, 1 );
	$sContent = curl_exec($oCurl);
	$aStatus = curl_getinfo($oCurl);
	curl_close($oCurl);
	if(intval($aStatus["http_code"])==200){
		return $sContent;
	}else{
		return false;
	}
}
function _U($model)
{
	if($model=='refush')
	{
		return 'javascript:window.location.reload();';
	}
	return U($model,array('name'=>get_uid()));
}
function FW($url='')
{
	return $url;
	//return U('Index/forward',array('url'=>urlencode($url) ));
}
function msubstr($str, $start = 0, $length, $charset = "utf-8", $suffix = true) {

	if (function_exists ( "mb_substr" ))

		$slice = mb_substr ( $str, $start, $length, $charset );

	elseif (function_exists ( 'iconv_substr' )) {

		$slice = iconv_substr ( $str, $start, $length, $charset );

		if (false === $slice) {

			$slice = '';

		}

	} else {

		$re ['utf-8'] = "/[\x01-\x7f]|[\xc2-\xdf][\x80-\xbf]|[\xe0-\xef][\x80-\xbf]{2}|[\xf0-\xff][\x80-\xbf]{3}/";

		$re ['gb2312'] = "/[\x01-\x7f]|[\xb0-\xf7][\xa0-\xfe]/";

		$re ['gbk'] = "/[\x01-\x7f]|[\x81-\xfe][\x40-\xfe]/";

		$re ['big5'] = "/[\x01-\x7f]|[\x81-\xfe]([\x40-\x7e]|\xa1-\xfe])/";

		preg_match_all ( $re [$charset], $str, $match );

		$slice = join ( "", array_slice ( $match [0], $start, $length ) );

	}

	

	return $suffix && $str != $slice ? $slice . '...' : $slice;

}

/**

 * 方法增强，根据$length自动判断是否应该显示...

 * 字符串截取，支持中文和其他编码

 * QQ:125682133

 *

 * @access public

 * @param string $str

 *        	需要转换的字符串

 * @param string $start

 *        	开始位置

 * @param string $length

 *        	截取长度

 * @param string $charset

 *        	编码格式

 * @param string $suffix

 *        	截断显示字符

 * @return string

 */

function msubstr_local($str, $start = 0, $length, $charset = "utf-8") {

	if (function_exists ( "mb_substr" ))

		$slice = mb_substr ( $str, $start, $length, $charset );

	elseif (function_exists ( 'iconv_substr' )) {

		$slice = iconv_substr ( $str, $start, $length, $charset );

		if (false === $slice) {

			$slice = '';

		}

	} else {

		$re ['utf-8'] = "/[\x01-\x7f]|[\xc2-\xdf][\x80-\xbf]|[\xe0-\xef][\x80-\xbf]{2}|[\xf0-\xff][\x80-\xbf]{3}/";

		$re ['gb2312'] = "/[\x01-\x7f]|[\xb0-\xf7][\xa0-\xfe]/";

		$re ['gbk'] = "/[\x01-\x7f]|[\x81-\xfe][\x40-\xfe]/";

		$re ['big5'] = "/[\x01-\x7f]|[\x81-\xfe]([\x40-\x7e]|\xa1-\xfe])/";

		preg_match_all ( $re [$charset], $str, $match );

		

		$slice = join ( "", array_slice ( $match [0], $start, $length ) );

	}

	return (strlen ( $str ) > strlen ( $slice )) ? $slice . '...' : $slice;

}
function str_urldecode_trim($str)
{
	return str_replace('"','',urldecode($str));
}
function str_get_describe($str='',$str2='',$len=120,$tip='...')
{
	if($str!=''&&$str2!='')
	{
		$str=$str.','.$str2;
	}
	if($str=='')
	{
		$str=$str2;
	}
	$strl=strlen($str);
	$str=str_replace('&nbsp;','',$str);
	$str=str_replace('<br/>;','',$str);
	$str=strip_tags($str);
	if($strl>$len)
	{
		$str=iconv_substr($str,0,$len,'utf-8').$tip;
	}
	return $str;
}

/**
 * 时间戳格式化
 *
 * @param int $time        	
 * @return string 完整的时间显示
 * @author huajie <banhuajie@163.com>
 */
function time_format($time = NULL, $format = 'Y-m-d H:i') {
	if (empty ( $time ))
		return '';
	
	$time = $time === NULL ? NOW_TIME : intval ( $time );
	return date ( $format, $time );
}
function day_format($time = NULL) {
	return time_format ( $time, 'Y-m-d' );
}
function hour_format($time = NULL) {
	return time_format ( $time, 'H:i' );
}
function time_offset($time = NULL) {
	if (empty ( $time ))
		return '00:00';
	
	$mod = $time % 60;
	$min = ($time - $mod) / 60;
	
	$mod < 10 && $mod = '0' . $mod;
	$min < 10 && $min = '0' . $min;
	
	return $min . ':' . $mod;
}
function think_weiphp_md5($str, $key = '') {
	empty ( $key ) && $key = C ( 'DATA_AUTH_KEY' );
	return '' === $str ? '' : md5 ( sha1 ( $str ) . $key );
}
function getToday($time) {
	    if($time==null)
		{
			$time=time();
		}
		$date = date ( 'Y-m-d 00:00:00', $time );
		$temp = explode ( " ", $date );
		$temp1 = explode ( "-", $temp [0] );
		$temp2 = explode ( ":", $temp [1] );
		$today = mktime ( $temp2 [0], $temp2 [1], $temp2 [2], $temp1 [1], $temp1 [2], $temp1 [0] );
		
		return $today;
	}
function format_date($time){  
    $t=time()-$time;  
    $f=array(  
        '31536000'=>'年',  
        '2592000'=>'月',  
        '604800'=>'周',  
        '86400'=>'天',  
        '3600'=>'小时',  
        '60'=>'分钟',  
        '1'=>'秒'  
    );  
    foreach ($f as $k=>$v)    {  
        if (0 !=$c=floor($t/(int)$k)) {  
            return $c.$v.'前';  
        }  
    } 
    
} 
/**
    * 导出数据为excel表格
    *@param $data    一个二维数组,结构如同从数据库查出来的数组
    *@param $title   excel的第一行标题,一个数组,如果为空则没有标题
    *@param $filename 下载的文件名
    *@examlpe 
    $stu = M ('User');
    $arr = $stu -> select();
    exportexcel($arr,array('id','账户','密码','昵称'),'文件名!');
*/
function exportexcel($data=array(),$title=array(),$filename='report'){
    header("Content-type:application/octet-stream");
    header("Accept-Ranges:bytes");
    header("Content-type:application/vnd.ms-excel");  
    header("Content-Disposition:attachment;filename=".$filename.".xls");
    header("Pragma: no-cache");
    header("Expires: 0");
    //导出xls 开始
    if (!empty($title)){
        foreach ($title as $k => $v) {
            $title[$k]=iconv("UTF-8", "GB2312",$v);
        }
        $title= implode("\t", $title);
        echo "$title\n";
    }
    if (!empty($data)){
        foreach($data as $key=>$val){
            foreach ($val as $ck => $cv) {
                $data[$key][$ck]=iconv("UTF-8", "GB2312", $cv);
            }
            $data[$key]=implode("\t'", $data[$key]);
            
        }
        echo implode("\n",$data);
    }
}
  
     
     function download_excel($data, $fileName)
    {
	    $limit = 10000;
        $fileName = _charset($fileName);
        header("Content-Type: application/vnd.ms-excel; charset=gbk");
        header("Content-Disposition: inline; filename=\"" . $fileName . ".xls\"");
        echo "<?xml version=\"1.0\" encoding=\"gbk\"?>\n
            <Workbook xmlns=\"urn:schemas-microsoft-com:office:spreadsheet\"
            xmlns:x=\"urn:schemas-microsoft-com:office:excel\"
            xmlns:ss=\"urn:schemas-microsoft-com:office:spreadsheet\"
            xmlns:html=\"http://www.w3.org/TR/REC-html40\">";
        echo "\n<Worksheet ss:Name=\"" . $fileName . "\">\n<Table>\n";
        $guard = 0;
        foreach($data as $v)
        {
            $guard++;
            if($guard==$limit)
            {
                ob_flush();
                flush();
                $guard = 0;
            }
            echo _addRow(_charset($v));
        }
        echo "</Table>\n</Worksheet>\n</Workbook>";
    }
     
     function _addRow($row)
    {
        $cells = "";
        foreach ($row as $k => $v)
        {
            $cells .= "<Cell><Data ss:Type=\"String\">" . $v . "</Data></Cell>\n";
        }
        return "<Row>\n" . $cells . "</Row>\n";
    }
     
     function _charset($data)
    {
        if(!$data)
        {
            return false;
        }
        if(is_array($data))
        {
            foreach($data as $k=>$v)
            {
                $data[$k] = _charset($v);
            }
            return $data;
        }
        return iconv('utf-8', 'gbk', $data);
    } 
	
	
	function get_n_url($url)
	{
		
		if(strpos($url,'?')!== false||strpos($url,'&')!== false)
		{
			$url=md5($url);
		}
		else if(strpos($url,'/index/content/id/')!== false)
		{
			$url=str_replace('/index/content/id/','/p/',$url);
		}
		else if(strpos($url,'/index/bbs/name/')!== false)
		{
			$url=str_replace('/index/bbs/name/','/bbs/',$url);
		}
		else if(strpos($url,'/index/index/name/')!== false)
		{
			$url=str_replace('/index/index/name/','/',$url);
		}
	 
		else
		{
			$url=md5($url);
		}
		$url=str_replace('/type/','_type_',$url);
		$url=str_replace('/page_type/','_page_type_',$url);
		$url=str_replace('/reply_id/','_reply_id_',$url);
		$url=str_replace('.html','',$url);
		return $url;
	}
