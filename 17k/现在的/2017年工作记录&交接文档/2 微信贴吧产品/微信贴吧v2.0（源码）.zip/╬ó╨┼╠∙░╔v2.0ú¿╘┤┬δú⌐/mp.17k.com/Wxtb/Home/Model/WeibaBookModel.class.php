<?php
namespace Home\Model;
use Think\Model; 
class WeibaBookModel extends Model {
	function get_readbook($token)
	{
		$map['token']=$token;
		$map['isreadpage']=1;
		$data=$this->field ( true)->cache(true)->where ( $map )->find();
		return $data;
	}
	
}