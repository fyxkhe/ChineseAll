<?php
namespace Home\Controller;
use Think\Controller;
class IndexController extends Controller {
	function _initialize() {
		if (IS_POST)
		{
			
		}
	    else
		{
			

		}
		$this->contextdata=D('Home/public')->publicdata();
		$this->webname=get_webname();
		$this->publicdata=$this->contextdata[$this->webname];
		$this->token=$this->publicdata['token'];
		$this->bbs=D('Home/weiba')->get_bbs($this->token,'bbs');
		$this->page_title=$this->bbs['weiba_name'].'_'.$this->bbs['intro'];
		$this->keywords=$this->bbs['weiba_name'];
		$this->description=$this->bbs['intro'];
		$this->imgurl=get_cover_url($this->bbs['logo']);
	}
	public function wait($limitcount=10,$jump_url='',$key='',$userkey=null,$istest=true)
	{
		if($istest)
		{
			return null;
		}
		else
		{
				
		}
		if(!IS_POST)
		{
			$data=load_limit($limitcount,$jump_url,$key,$userkey);
			
			if($data!=null)
			{
				$this->load_data=$data;
				$this->display('wait');
				die;
			}
		}
		
	}
	public function limit_test()
	{
		$this->wait(1,'','','',false);
		dump('通过');
	}
	public function game_url($name='',$type='gift')
	{
		/*
		$ldata=load_limit();
		if($ldata!=null&&$ldata['jump_time']>0)
		{
			$this->success('当前访问人数太多，您需等待'.$ldata['count'].'人！',$ldata['url'],$ldata['jump_time']);
		}
		*/
		/*
		$ky='index_game_url';
		$ct=S($ky);
		if($ct==null)
		{
			$ct=1;
		}
		else
		{
			$ct++;
		}
		S($ky,$ct,60);
		*/
		$this->wait(5);
		$islogin=I('islogin',0);
		$must_login=($islogin==1?true:false);
		$userdata=get_userinfo(0,$must_login);
		if($userdata==null)
		{
			$callback=GetCurUrl().'&islogin=1';
			$this->error('需要登陆才能继续！',$callback,3);
		}
		$map['token']=$name;
		$map['tagname']=$type;
		$gifttag=M('weiba_users_tag')->where($map)->cache(true)->find();
		if($gifttag!=null)
		{
			redirect($gifttag['tagurl'].'&from=17k'); 
		}
	}
	public function bangdan($name='',$type='active')
	{
		$userdata=get_userinfo(0,false);
		if($userdata==null)
		{
			$userdata['uid']=-1;
		}
		if($type=='active')
		{
			$list_data=R('Api/get_active',array($name,$userdata['uid'],$this->bbs['id']));
			$data=$list_data['data'];
			$allcount=$list_data['count'];
		}
		else if($type=='singin')
		{
			$list_data=R('Api/get_singin',array($name,$userdata['uid'],$this->bbs['id'])); 
			$data=$list_data['data'];
			$allcount=$list_data['count'];
			if($userdata['uid']>0)
			{
				$data[0]['nickname']= str_urldecode_trim($data[0]['nickname']); 
				$data[0]['headimgurl']=  $userdata['headimgurl'];
			}
			
		}
		else if($type=='supfans')
		{
			$list_data=R('Api/get_supfans',array($name,$userdata['uid'],$this->bbs['id'])); 
			$data=$list_data['data'];
			$allcount=$list_data['count'];
			if($userdata['uid']>0)
			{
				$data[0]['nickname']= str_urldecode_trim($data[0]['nickname']); 
				$data[0]['headimgurl']=  $userdata['headimgurl'];
			}
		}
		if($userdata['uid']<0)
		{
			$data[0]['uid']='';
			$data[0]['usertag']='';
			$data[0]['nickname']=get_login($name,'none','','点此登陆查看自己信息') ;
		}
		$this->allcount=$allcount;
		$this->list_data=$data;
		$this->display();
	}
	public function reserve($rid=0,$id=0)
	{
		$url='http://mp.authorcrm.com/admin/index.php?s=/addon/Reserve/Wap/reserve_success/reserve_id/'.$rid.'/id/'.$id.'/model/192.html&isadmin=1';
		redirect($url);
	}
	public function topbar()
	{
		$this->display();
	}
	public function _empty()
	{
		redirect(U('index/index'));
	}
	public function usertest()
	{
		$userdata=get_userinfo(0,false);
		//
		 if(isset($userdata['errcode']))
		{
			 
			$userdata=get_userinfo(1);
		}
		else if($userdata['uid']>0)
		{
			$udata=M('user_login')->where('uid='.$userdata['uid'])->cache(true)->find();
			if($udata!=null)
			{
				$userdata=get_userinfo(1);
			}
		}
		  
		dump($userdata);
	}
	public function signin($token='')
	{
		$userdata=get_userinfo();
		if(IS_POST)
		{
			if(!$userdata)
			{
				$data['ret']=0;
				$data['errmsg']='请先登陆!';
				$this->ajaxReturn($data);
			}
		}
		if($token==null)
		{
			$token=get_webname();
		}
		$singdata=D('Home/WeibaUsers')->SingIn($userdata['uid'],$token);
		$today=getToday(time());
		$singin_key='SingIn_'.$token.'_'.$today;
		$singtop=D('Home/WeibaUsers')->get_singin_top($singin_key,100);
		$singdata=json_decode($singdata,true);
		$this->singdata= $singdata;
		$this->singtop=$singtop;
		if(IS_POST)
		{
			$content='';
			
				
			$data['ret']=1;
			$data['errmsg']='';
			$this->ajaxReturn($data);
			
		}
		dump($singdata);
		dump($singtop);
		//$this->display();
		
	}
	public function faxian()
	{
		
		if($userdata['headimgurl']==null||$userdata['headimgurl']=='/admin/Addons/UserCenter/View/default/Public/default_head.png')
		{
			$userdata=get_userinfo(1);
		}
		
		$this->display();
	}
	public function supfans($name='')
	{
		$userdata=get_userinfo();
		if(!$this->is_supadmin($userdata['uid'],$this->bbs['id']))
		{
			$this->error('无权限访问'); 
		}
		$map['token']=$name;
		 
		$data=M('weiba_tag_view')->where($map)->where('status>=0')->order('status asc, click_count desc,score desc')->cache(true)->select();
		 
		foreach($data as &$da)
		{
			$da['nickname']=str_urldecode_trim($da['nickname']);
			if($da['score']==null)
			{
				$da['score']=0;
			}
			if($da['click_count']==null)
			{
				$da['click_count']=0;
			}
			if($da['status']==0)
			{
				$da['status']='待审核';
			}
			else
			{
				$da['status']='已通过';
			}
			$da['url']=$da['tagvalueurl'];
			$da['usertag']=$da['tagname'].'&nbsp;<a href="'.$da['url'].'">'.$da['status'].'</a>'; 
		}
		$this->list_data=$data;
		$this->display();
	}
	public function fans($name='xiaoheiwu',$tagid=0)
	{
		$userdata=get_userinfo(0,false);   
		if($userdata==null)
		{
			$userdata['uid']=-1;
		}
		//dump($userdata);
		/*
		$is_supadmin=0;
		if($this->is_supadmin($userdata['uid'],$this->bbs['id']))
		{
			$is_supadmin=1;
		}*/
		$i=0;
		$map['token'] = $name;
		$map['uid']=$userdata['uid'];
		$data1=M('weiba_users_view')->where($map)->cache(true)->find();
		
		if($data1!=null)
		{
			$data1['usertag']=get_users_tag($userdata['uid'],$this->bbs['id']);
			$data1['nickname']=str_urldecode_trim($data1['nickname']);
			
			
			
		}
		else
		{
			$userdata['uid']='';
			$data1['usertag']='';
			$data1['nickname']=get_login($name,'登陆可查看自己信息') ;
		}
		$data1['color']='red';   
		$fansdata[$i]=$data1;   
		$i++; 
		unset($map);
		$map['token'] = $name;  
		$data=M('weiba_users_view')->where($map)->order('click_count desc,score desc')->cache(true)->limit(0,100)->select();
		foreach($data as &$da)
		{
			if($da['uid']!=$userdata['uid'])
			{
				$da['usertag']=get_users_tag($da['uid'],$this->bbs['id']);
				$da['nickname']=str_urldecode_trim($da['nickname']); 
				$fansdata[$i]=$da;
				$i++;
			}
		}
		/*
	    if($tagid>0)
		{
			$map['tagid']=$tagid;
		}
		$data=M('weiba_tag_view')->where($map)->order('click_count desc,score desc')->cache(true)->select();
		foreach($data as &$da)
		{
			if($da['score']==null)
			{
				$da['score']=0;
			}
			if($da['click_count']==null)
			{
				$da['click_count']=0;
			}
			if($is_supadmin==1)
			{
				$da['url']=$da['tagvalueurl'];
				 
			}
			else
			{
				$da['url']=$da['tagurl'];
			}
			
		}
		*/
		 $this->page_title=$this->bbs['weiba_name'].'-粉丝榜';
		$this->list_data=$fansdata;
		$this->display();
	}
	public function test($type='',$bookid=0)
	{
		$ur=urlencode(urlencode('http://h5.17k.com/mianfei/?hmsr=weixin'));
		$url='https://open.weixin.qq.com/connect/oauth2/authorize?appid=wxef3ef657963be572&redirect_uri=http%3A%2F%2Fopen.wechat.17k.com%2Ftransfer%2Fhandler%3Fredirect_url%3D'.$ur.'&response_type=code&scope=snsapi_base&state=EB8B5293C078E4104027165AAA0349B9#wechat_redirect';
		 dump($url);
		 die;
			 
		//获取追书数据
			if($bookid!=0)
			{
				$book=M('weiba_book')->where(array('id'=>$bookid))->find();
			}
			else
			{
				$book=D('Home/weiba_book')->get_readbook($this->token);
			}
			$this->bookdata=$book;
			$chapterlist=$this->chapterlistdata($book['context'],$book['bookid']); 
			if(count($chapterlist)>0)
			{
				
				$this->updatetime=$chapterlist[0]['updateDate']/1000;
			}
			$this->assign ( 'chapterlist', $chapterlist );
			$this->page_title=$book['bookname'].'_最新章节';
			$this->keywords=$book['bookname'].','.$book['authorname'];
			$this->description=$book['bookdescribe'];
			$this->page_type=$type;
			//显示公告
			//显示评论
			$list_data=$this->bbs_getdata($this->bbs['id'],0,10);  
			 
			foreach($list_data as &$li)
			{
				$li['nickname']=str_urldecode_trim($li['nickname']);
				$li['post_time']=time_format($li['post_time']);
				//$li['title']=str_get_describe($li['title'],$li['content'],19);
				if($li['jump_url']==null)
				{
					$li['jump_url']=U('index/content',array('id'=>$li['id']));
				}
				else
				{
					$li['is_link']=1;
				}
			}
			$this->list_data=$list_data;
	
		$this->display();
	}
	public function allshelf()
	{
		
		$data=M('weiba_book')->where(array('isreadpage'=>1))->order('sortnum desc')->select();
		foreach($data as &$li)
			{
				//$li['jump_url']=$li['bookurl'];
				$li['logourl']=get_cover_url($li['logourl']);
				if($li['open_type']=='link')
				{
					$li['jump_url']=$li['bookurl'];
				}
				else
				{
					$li['jump_url']=U('index/chapterlist',array('bookid'=>$li['id']));
				}
			}
		$this->data=$data;
		$this->display();
	}
	
	public function mydata()
	{
		$userdata=get_userinfo();
		if(IS_POST)
		{
			$username=trim(I('post.username',null));
			if($username!=null)
			{
				$data['login_name']=$username;
				//判断用户名是否重复
				$yzdata=M('user')->where($data)->select();
				$rs['url']=U('index/my');
				if(count($yzdata)>1)
				{
					$rs['ret']=0;
					$rs['errmsg']='用户名被占用';
					$this->ajaxReturn($rs);
				}
				else if(count($yzdata)==1)
				{
					if($yzdata[0]['uid']!=$userdata['uid'])
					{
						$rs['ret']=0;
						$rs['errmsg']='用户名被占用';
						$this->ajaxReturn($rs);
					}
				}
			}
			$pwd=trim(I('post.password',''));
			if($pwd!=null)
			{
				$pwd=think_weiphp_md5($pwd);
				$data['login_password']=$pwd;
				$data['password']=$pwd;
			}
			
			$data['last_login_time']=time();
			$data['truename']=I('post.truename','');
			$data['mobile']=I('post.mobile','');
			$data['address']=I('post.address','');
			$data['qq']=I('post.qq','');
			$data['wechat']=I('post.wechat','');
			M('user')->where(array('uid'=>$userdata['uid']))->save($data);
			$rs['ret']=1;
			$rs['errmsg']='修改成功';
			$this->ajaxReturn($rs);
			
		}
		$data=M('user')->where(array('uid'=>$userdata['uid']))->find();
		if($data==null)
		{
			$this->error('用户不存在!');
		}
		$userdata['username']=$data['login_name'];
		 $userdata['username']=$data['login_name'];
		$userdata['truename']=$data['truename'];
		$userdata['mobile']=$data['mobile'];
		$userdata['address']=$data['address'];
		$userdata['qq']=$data['qq'];
		$userdata['wechat']=$data['wechat'];
		$this->userdata=$userdata;
		$this->display();
	}
	public function myjoin($weiba_id=0,$page_index=1,$page_size=30,$page_type=1)
	{
		$this->page_type=I('page_type',1);
		$weiba_id=I('weiba_id',$this->bbs['id']);
		$userdata=get_userinfo();
		$post_uid=$userdata['uid'];
		if(IS_POST)
		{
			if($page_type==1)//我的发帖
			{
				$map['post_uid']=$post_uid;
				$list_data=M('weiba_post_view')->field ( true)->where ( $map )->page($pageindex,$pagesize)->select();
			}
			else if($page_type==2)//我的回帖
			{
				$map['uid']=$post_uid;
				
				$list_data=M('weiba_post_reply_view')->field ( true)->where ( $map )->page($pageindex,$pagesize)->select();
			}
			else if($page_type==3)//我的收藏
			{
				$map['uid']=$post_uid;
				
				$list_data=M('weiba_post_favorite_view')->field ( true)->where ( $map )->page($pageindex,$pagesize)->select();
			}
			$dsize=count($list_data);
			if($list_data!=null&&($dsize==intval($page_size)))
			{
				$page_index=$page_index+1;
			}
			if($list_data==null)
			{
				$data['ret']=0;
				$data['errmsg']='已加载全部数据';
				
			}
			else
			{
				foreach($list_data as &$li)
				{
					$li['nickname']=str_urldecode_trim($li['nickname']);
					$li['usertag']=get_users_tag($li['post_uid'],$this->bbs['id']);
					$li['post_time']=time_format($li['post_time']);
					$li['content']=str_get_describe($li['content']);
					if($li['jump_url']==null)
					{
						$li['jump_url']=U('index/content',array('id'=>$li['id']));
						
					}
					else
					{  
						$li['is_link']=1;
					}
				}
				$data['ret']=1;
				$data['page_index']=$page_index;
				$data['page_size']=$page_size;
				$data['page_type']=$page_type;
				$data['userdata']=$this->userdata;
				$data['webdata']=$this->webdata;
				$data['list_data']=$list_data;
			}
			
			$this->ajaxReturn($data);
		}
		
		$this->page_index=$page_index;
		$this->page_size=$page_size;
		$this->page_type=$page_type;
		$this->weiba_id=$weiba_id;
 
		$this->display();
	}
	public function chapterlistdata($type='17k',$bookid='1198584',$isdata=0)
	{
	//获取当天的年份
		$y = date("Y");
		//获取当天的月份  
		$m = date("m");
		//获取当天的号数
		$d = date("d");
		$todayTime= mktime(0,0,0,$m,$d,$y);
		if($type=='17k')
		{
			$zjdata;
			$data=http_get('http://h5.17k.com/h5/book/ajaxBookList.k?jsonp=Q.JsonpTmpCallback_9638156634367314&bookId='.$bookid.'&page=1&orderType=1&zzaqkey=558839932');
			$data=json_decode($data,true);
			if($data!=null)
			{
				foreach($data['datas'] as $k=>$v)
				{
					
					$v['createDate']=$v['createDate']/1000;
					if($v['createDate']>=$todayTime)
					{
						$v['color']='red';
					}
					else
					{
						$v['color']='black';
					}
					
					if($v['isVIP']=='N')
					{
						$chapter='chapter';
					}
					else
					{
						$chapter='vipchapter';
					}
					
					
					
					$v['url']='http://h5.17k.com/'.$chapter.'/'.$bookid.'/'.$v['id'].'.html' ;
					if($v['volumeName']!='')
					{
						$v['name']=$v['volumeName'];
						
					}
					if(isset($zjdata[$v['id']]))
					{
						$p=$zjdata[$v['id']];
						$temp=$chapterlist[$p];
						$chapterlist[$p]=$v;
						$v=$temp;
					}	
					$zjdata[$v['id']]=$k;
					$chapterlist[$k] =$v;
				} 
			}
			else
			{
				$url='http://www.17k.com/list/'.$bookid.'.html';
				$html=file_get_contents($url);
				$dom=new \DOMDocument();
				$dom->loadHTML($html);
				$xml=simplexml_import_dom($dom);
				$nav=$xml->xpath('//div[@class="Main List"]/dl/dd/a');
				$ct=count($nav);
				 for($i=0;$i<$ct;$i++)
				 {
					$title=(string)($nav[$ct-1-$i]->span);
					$cp_data=$nav[$ct-1-$i]->attributes();
					$createDate=(string)$cp_data['title'];
					$createDate=str_replace('更新日期:','|',$createDate);
					$keyarr=explode('|',$createDate); 
					 
					if(count($keyarr)>1)
					{
						$v['createDate']=strtotime($keyarr[1]);
						//$v['createDate']=$v['createDate']/1000;
						if($v['createDate']>=$todayTime)
						{
							$v['color']='red';
						}
						else
						{
							$v['color']='black';
						}
					}
					$href=(string)$cp_data['href'];
					$v['url']='http://h5.17k.com'.$href;
					$v['name']=$title;
					 
					$chapterlist[$i] =$v;

				 }
			}
		}
		else if($type=='pinyuew')
		{
			$url='http://pinyuew.com/bookChapter/'.$bookid.'.html';
			//$bookid='1004608738';
			//$url='https://m.qidian.com/book/'.$bookid.'/catalog';
			$html=file_get_contents($url);
			$html=str_replace('<meta charset="UTF-8">','<meta http-equiv="Content-Type" content="text/html;charset=utf-8">',$html);
			
			$dom=new \DOMDocument();
			$dom->loadHTML($html);
			
			$xml=simplexml_import_dom($dom);
			
			$nav=$xml->xpath('//div[@class="u-volume-item"]/div/a');
			 
			//$nav=$xml->xpath('//div[@id="catelogX"]/ol/li/a');
			$jsonStr = json_encode($nav);
			$jsonArray = json_decode($jsonStr,true);
			$ct=count($jsonArray);
			$i=0;
			 
			foreach($jsonArray as $ja)
			{
				$title=$ja['0'];
				$cp_data=$ja['@attributes'];
				
				$createDate=$cp_data['data-time'];
			 
				$v['createDate']=strtotime($createDate);
					//$v['createDate']=$v['createDate']/1000;
				if($v['createDate']>=$todayTime)
				{
					$v['color']='red';
				}
				else
				{
					$v['color']='black';
				}
				$hr=$cp_data['onclick'];
				$hr=str_replace('getContentLink(','',$hr);
				$hr=str_replace(')','',$hr);
				$keyarr=explode(',',$hr); 
				$href='http://m.pinyuew.com/index.php/page/book_read/'.trim($keyarr[0]).'/'.trim($keyarr[1]);
			  
				$v['url']=$href;
				$v['name']=$title;
				
				$chapterlist[$i]=$v;
				$i++;
			}
			$chapterlist=array_reverse($chapterlist);   
		}
		else if($type=='qidian')
		{
			$url='https://book.qidian.com/info/1004608738#Catalog';
			//$bookid='1004608738';
			//$url='https://m.qidian.com/book/'.$bookid.'/catalog';
			$html=file_get_contents($url);
			$html=str_replace('<meta charset="UTF-8">','<meta http-equiv="Content-Type" content="text/html;charset=utf-8">',$html);
			
			$dom=new \DOMDocument();
			$dom->loadHTML($html);
			
			$xml=simplexml_import_dom($dom);
			
			$nav=$xml->xpath('//div[@class="volume"]/ul/li/a');
			 
			//$nav=$xml->xpath('//div[@id="catelogX"]/ol/li/a');
			$jsonStr = json_encode($nav);
			$jsonArray = json_decode($jsonStr,true);
			$ct=count($jsonArray);
			$i=0;
		 
			foreach($jsonArray as $ja)
			{
				$title=$ja['0'];
				$cp_data=$ja['@attributes'];
				
				$createDate=$cp_data['title'];
			 
				$createDate=str_replace('更新日期:','|',$createDate);
				$keyarr=explode('|',$createDate); 
				if(count($keyarr)>1)
				{
					$v['createDate']=strtotime($keyarr[1]);
					//$v['createDate']=$v['createDate']/1000;
					if($v['createDate']>=$todayTime)
					{
						$v['color']='red';
					}
					else
					{
						$v['color']='black';
					}
				}
				////vipreader.qidian.com/chapter/1004608738/389361566
				//https://m.qidian.com/book/1004608738/389370102
				$href=str_replace('//vipreader.qidian.com/chapter/','https://m.qidian.com/book/',$cp_data['href']);
				$v['url']=$href;
				$v['name']=$title;
				
				$chapterlist[$i]=$v;
				$i++;
			}
			 $chapterlist=array_reverse($chapterlist);   
		
		}
		else if($type=='yys')
		{
			$data=M('view_bookfanwai')->cache(true)->where(array('bookid'=>$bookid))->select();
			$index=0;
			foreach($data as $k=>$v) 
			{
				$v['createDate']=strtotime($v['cdate']);
				if($v['createDate']>=$todayTime)
				{
					$v['color']='red';
				}
				else
				{
					$v['color']='black';
				}
				$v['url']='http://www.authorcrm.com/project/nbbs/bbs.php?s=/home/index/fanwai/bookid/'.$v['bookid'].'/chapterid/'.$v['chapterid'].'.html'; 
				$v['name']=$v['title'];
				$chapterlist[$index] =$v;
				$index=$index+1;
				 
			}
			 
		}
		else if($type=='weixin')
		{
			$data=M('wxarticle')->cache(true)->where(array('bookid'=>$bookid))->order('ordernum desc')->select();
			$index=0;
			foreach($data as $k=>$v) 
			{
				$v['createDate']=strtotime($v['cdate']);
				if($v['createDate']>=$todayTime)
				{
					$v['color']='red';
				}
				else
				{
					$v['color']='black';
				}
				$v['name']=$v['title'];
				$chapterlist[$index] =$v;
				$index=$index+1;
				 
			}
		}
		if($chapterlist==null||$chapterlist==false)
		{
			$chapterlist=s($type.$bookid);
		}
		else
		{
			s($type.$bookid,$chapterlist);
		}
		if($isdata==1)
		{
			$d=urlencode( json_encode($chapterlist));
			$this->show($d);  
		}
		return $chapterlist;
		
	}
    public function index($type='',$bookid=0,$name='xiaoheiwu'){
		$INDEX_PAGE=C('INDEX_PAGE');
		if($INDEX_PAGE[$name]!=null)
		{
			$type=$INDEX_PAGE[$name];
			redirect(U($type,array('name'=>$name)));
		}
		
		if($type==''||$type=='read')
		{
			$type='index';
		}
		if($type=='index')
		{
			
			//获取追书数据
			if($bookid!=0)
			{
				$book=M('weiba_book')->where(array('id'=>$bookid))->find();
			}
			else
			{
				$book=D('Home/weiba_book')->get_readbook($this->token);
			}
			if($book['open_type']=='link')
			{
				redirect($book['bookurl']);
			}
			$this->bookdata=$book;
			$chapterlist=$this->chapterlistdata($book['context'],$book['bookid']); 
			
			$this->help_data=get_help($book['context']);
			if(count($chapterlist)>0)
			{
				$this->updatetime=$chapterlist[0]['createDate'];
			}
			$this->assign ( 'chapterlist', $chapterlist );
			
			if($book['index_title']==null)
			{
				$book['index_title']='('.$book['authorname'].')'.$book['context'].'小说_'.$book['bookname'].'最新章节';
			}
			$this->page_title=$book['bookname'].$book['index_title'];
			$this->keywords=$book['bookname'].','.$book['authorname'];
			$this->description=$book['bookdescribe'];
			$this->page_type=$type;
			$book['logourl']=get_cover_url($book['logourl']);
			$bookurl=U('index/index',array('name'=>$name));
			if($book['category']==null)
			{
				$book['category']='网络小说';
			}
			$head_more='<meta property="og:type" content="novel"/>
						<meta property="og:title" content="'.$book['bookname'].'"/>
						<meta property="og:description" content="'.$book['bookdescribe'].'"/>
						<meta property="og:image" content="'.$book['logourl'].'"/>
						<meta property="og:novel:category" content="'.$book['category'].'"/>
						<meta property="og:novel:author" content="'.$book['authorname'].'"/>
						<meta property="og:novel:book_name" content="'.$book['bookname'].'"/>
						<meta property="og:novel:read_url" content="'.$bookurl.'"/>
						<meta property="og:url" content="'.$bookurl.'"/>
						<meta property="og:novel:status" content="连载中"/>
						<meta property="og:novel:update_time" content="'.date('Y-m-d H:i:s',$this->updatetime).'"/>
						<meta property="og:novel:latest_chapter_name" content="'.$chapterlist[0]['name'].'"/>
						<meta property="og:novel:latest_chapter_url" content="'.$bookurl.'"/>';
			
			$this->head_more=$head_more;
			
			//显示公告
			//显示评论
			$default_data=D('Home/weiba')->get_bbs(DEFAULT_TOKEN,'bbs');
			
			$nmap['weiba_id']=$default_data['id'];
			$nmap['styletype']='notice';
			$noticelist=M('weiba_post')->field('id,title')->where($nmap)->order('top_time desc,post_time desc')->limit(0,3)->cache(true)->select(); 
			foreach($noticelist as &$li)
			{
				if($li['describe']!=null)
				{
					$li['content']=$li['describe'];
				}
				
				$li['title']=str_get_describe($li['title'],$li['content'],200,'');
				
				if($li['jump_url']==null)
				{
					$li['jump_url']=U('index/content',array('id'=>$li['id']));
					
				}
				else
				{
					$li['is_link']=1;
				}
			}
			$this->noticelist=$noticelist;
			$userdata=get_userinfo(0,false);
			$hot_data=$this->bbs_getdata($this->bbs['id'],0,6,4,$userdata['uid']);
			if(count($hot_data)<6)
			{
				$hot_data=$this->bbs_getdata($this->bbs['id'],0,6,5,$userdata['uid']);
			}
			foreach($hot_data as &$li)
			{
				if($li['describe']!=null)
				{
					$li['content']=$li['describe'];
				}
				if($li['styletype']=='notice')
				{
					$li['color']='red';
				}
				else  
				{
					$li['styletype']='hot';
				}
				$li['title']=str_get_describe($li['title'],$li['content'],100,'');
				
				if($li['jump_url']==null)
				{
					$li['jump_url']=U('index/content',array('id'=>$li['id']));
					
				}
				else
				{
					$li['is_link']=1;
				}
			}
			$this->hot_data=$hot_data;
			
			
			$list_data=$this->bbs_getdata($this->bbs['id'],0,4,1,0);

			foreach($list_data as &$li)
			{
				$li['nickname']=str_urldecode_trim($li['nickname']);
				$li['post_time']=time_format($li['post_time']);
				//$li['title']=str_get_describe($li['title'],$li['content'],19);
				if($li['describe']!=null)
				{
					$li['content']=$li['describe'];
				}
				else
				{
					$li['content']=str_get_describe($li['content']);
				}
				if($li['jump_url']==null)
				{
					$li['jump_url']=U('index/content',array('id'=>$li['id']));
				}
				else
				{
					$li['is_link']=1;
				}
			}
			$this->list_data=$list_data;
			
		}
		else if($type=='shelf')
		{
			$map['token']=$this->token;
			$map['catetype']=1;
			$map['status']=1;
			$data=M('weiba_book')->where($map)->order('sortnum desc')->select();
			foreach($data as &$li)
			{
				//$li['jump_url']=$li['bookurl'];
				$li['logourl']=get_cover_url($li['logourl']);
				if($li['open_type']=='link')
				{
					$li['jump_url']=$li['bookurl'];
				}
				else
				{
					$li['jump_url']=U('index/chapterlist',array('bookid'=>$li['id']));
				}
			}
			$this->data=$data;
			
		}
		else if($type=='fanwai')
		{
			$map['token']=$this->token;
			$map['catetype']=2;
			$map['status']=1;
			$data=M('weiba_book')->where($map)->order('sortnum desc')->select();
			foreach($data as &$li)
			{
				$li['logourl']=get_cover_url($li['logourl']);
				if($li['open_type']=='link')
				{
					$li['jump_url']=$li['bookurl'];
				}
				else
				{
					$li['jump_url']=U('index/chapterlist',array('bookid'=>$li['id']));
				}
			}
			
			
			$this->data=$data;
		}
		
	   $this->display($type);
    }
	public function chapter($bookid=0,$chapterid=0)
	{
		
	}
	public function chapterlist($bookid=0)
	{
		$book=M('weiba_book')->where(array('id'=>$bookid))->find();
		if($book==null||$book['status']==0)
		{
			$this->error('书籍不存在或被禁用!');
		}
		if($book['isreadpage']==1)
		{
			$public_data=D('Home/public')->get_public_by_token($book['token']);
			redirect(U('index/index',array('name'=>$public_data['wechat'])));
		}
		$map['bookid']=$bookid;
		$map['is_del']=0;
		$list_data=M('weiba_post')->where($map)->order('chapterid desc')->select();
	    
		foreach($list_data as &$li)
		{
			if($li['jump_url']=='')
			{
				//$li['jump_url']=U('index/chapter',array('bookid'=>$bookid,'chapterid'=>$li['chapterid']));
				$li['jump_url']=U('index/content',array('id'=>$li['id']));
			}
			
		}
		$this->updatetime=$list_data[0]['post_time'];
		if($book['index_title']==null)
		{
			$book['index_title']='('.$book['authorname'].')'.'_'.$book['bookname'].'最新章节';
		}
		$this->page_title=$book['bookname'].$book['index_title'];

		$this->keywords=$book['bookname'].','.$book['authorname'];
		$this->description=$book['bookdescribe'];
		$this->book=$book;
		$book['logourl']=get_cover_url($book['logourl']);
		
		$bookurl=U('index/chapterlist',array('bookid'=>$bookid));
		if($book['category']==null)
		{
			$book['category']='网络小说';
		}
		$head_more='<meta property="og:type" content="novel"/>
					<meta property="og:title" content="'.$book['bookname'].'"/>
					<meta property="og:description" content="'.$book['bookdescribe'].'"/>
					<meta property="og:image" content="'.$book['logourl'].'"/>
					<meta property="og:novel:category" content="'.$book['category'].'"/>
					<meta property="og:novel:author" content="'.$book['authorname'].'"/>
					<meta property="og:novel:book_name" content="'.$book['bookname'].'"/>
					<meta property="og:novel:read_url" content="'.$bookurl.'"/>
					<meta property="og:url" content="'.$bookurl.'"/>
					<meta property="og:novel:status" content="连载中"/>
					<meta property="og:novel:update_time" content="'.date('Y-m-d H:i:s',$this->updatetime).'"/>
					<meta property="og:novel:latest_chapter_name" content="'.$list_data[0]['title'].'"/>
					<meta property="og:novel:latest_chapter_url" content="'.$bookurl.'"/>';
		
		$this->head_more=$head_more;
		
		
		$this->list_data=$list_data;
		$this->display();
	}
	public function post()
	{
		$name=I('name','none');
		//获取用户信息
		$userdata=get_userinfo();
		
		if (IS_POST)
		{
			if(!$userdata)
			{
				$data['ret']=0;
				$data['errmsg']=get_login($name);
				$this->ajaxReturn($data);
			}
			
			if($_POST['title']==''&&$_POST['content']=='')
			{
				$data['ret']=0;
				$data['errmsg']='请输入内容!';
				$this->ajaxReturn($data);
			}
			$map['userid']=$userdata['uid'];
			$map['weiba_id']=$_POST['weiba_id'];
			$map['status']=1;
			$us=M('weiba_bbs_users')->where($map)->cache(true)->find();
			if($us!=null)
			{
				$rdata['ret']=0;
				$rdata['errmsg']='您暂无权限发帖！请联系管理员(微信yysxxdx)';
				$this->ajaxReturn($rdata);
				
			}
			if(!$this->is_supadmin($userdata['uid'],$_POST['weiba_id']))
			{
				if($name=='none')
				{
					$name=$_POST['weiba_id'];
				}
				if(!post_limit($name,$userdata['uid'],'post',3,60))
				{
					$rdata['ret']=0;
					$rdata['errmsg']='您发帖太频繁，请稍后再试！';
					$this->ajaxReturn($rdata); 
				}
			}
			
			/*
			//不能发重复帖子
			$post_key='last_post_'.$userdata['uid'].'_'.$_POST['weiba_id'];
			
			$new_post_data=$_POST['content'];
			if(isset($_COOKIE[$post_key]))
			{
				$post_data=$_COOKIE[$post_key];
				if($post_data==$new_post_data)
				{
					$rdata['ret']=0;
					$rdata['errmsg']='请勿发重复内容！';
					$this->ajaxReturn($rdata);
				}
			}
			setcookie($post_key,$new_post_data,120);
			*/
			//$_POST['content']=str_replace( "\r\n ", "<br />",$_POST['content']);
			//dump($_POST['content']);die;
			
			$sql="call pro_bbs_article_add("
					.$_POST['weiba_id'].",'"
					.$userdata['uid'].",'"
					.",'".$_POST['title']
					."','".$_POST['content']
					."','".$this->token
						."','".$_POST['jump_url']
					."',
					@ret,@errmsg)";
					$data=M()->procedure($sql);
				 
					$rdata['ret']=$data[0][0]['ret'];
					$rdata['errmsg']=$data[0][0]['errmsg'];
					//$rdata['url']=U ('bbs');
					$this->ajaxReturn($rdata);
					
		}
		else
		{
			if($userdata['uid']!=null)
			{
				
				$udata=M('user_login')->where('uid='.$userdata['uid'])->cache(true)->find();
				if($udata!=null)
				{
					$userdata=get_userinfo(1);
				}
			}
			
			//获取发布区域信息
		    $bbs=$this->bbs;//D('Home/weiba')->get_bbs($this->token,'bbs');
			$this->userdata=$userdata;
			$this->webdata=$bbs;
			if($this->bbs['is_shenhe']==-1)
			{
				$this->tip='注意：本吧设置了发帖审核，您发布的帖子需经过管理员(微信yysxxdx)审核后呈现！';
			}
			$this->page_title='发帖_'.$bbs['weiba_name'];
			$this->keywords=$bbs['weiba_name'];
			$this->description=$bbs['intro'];	
			
			//判断用户是否有权限
			$map['userid']=$userdata['uid'];
			$map['weiba_id']=$bbs['id'];
			$map['status']=1;
			$us=M('weiba_bbs_users')->where($map)->find();
			//dump($map);
			if($this->is_supadmin($userdata['uid'],$bbs['id']))
			{
				$this->supadmin=1;
			}
			if($us!=null)
			{
				$this->error("您暂无权限发帖！请联系管理员(微信yysxxdx)");
			}
			$this->display();
		}
	}
	
	public function post_reply($post_id=0,$content='',$to_reply_id=0,$mark='')
	{
		//dump('22');die;
		$userdata=get_userinfo();
		if(!$userdata)
		{
			$data['ret']=0;
			$data['errmsg']=get_login($name);
			$this->ajaxReturn($data);
		}
		
		$map['id']=$post_id;
		$article=M('weiba_post')->where($map)->find();
		$data['ret']=0;
		if($article==null)
		{
			$data['errmsg']='帖子不存在!';
			$this->ajaxReturn($data);
		}
		$reply['reply_id']=$to_reply_id;
		$reply['uid']=0;
		if($to_reply_id!=0)
		{
			$reply=M('weiba_reply')->where(array('reply_id'=>$to_reply_id))->find();
			if($reply==null)
			{
				$data['errmsg']='该回帖已被删除!';
				$this->ajaxReturn($data);
			}
		}
		if($article['lock']==1)
		{
			//判断帖子是否被锁定
			$data['errmsg']='帖子被锁定!';
			$this->ajaxReturn($data);
		}
		//判断用户是否有权限
		unset($map);
		$map['userid']=$userdata['uid'];
		$map['weiba_id']=$article['weiba_id'];
		$map['status']=1;
		$us=M('weiba_bbs_users')->where($map)->find();
		if($us!=null)
		{
			$data['errmsg']='您暂无权限发帖！请联系管理员(微信yysxxdx)';
			$this->ajaxReturn($data);
		}
		if(!$this->is_supadmin($userdata['uid'],$article['weiba_id']))
		{
			$name=$article['token'];
			if(!post_limit($name,$userdata['uid'],'post_reply',5,60))
			{
				$rdata['ret']=0;
				$rdata['errmsg']='您回帖太频繁，请稍后再试！';
				$this->ajaxReturn($rdata); 
			}
		}
		
		
		$weiba_data=M('weiba')->where(array('id'=>$article['weiba_id']))->find();
		$ctime=time();
		$replydata['weiba_id']=$article['weiba_id'];
		$replydata['post_id']=$post_id;
		$replydata['post_uid']=$article['post_uid'];
		$replydata['uid']=$userdata['uid'];
		$replydata['to_reply_id']=$reply['reply_id'];
		$replydata['to_uid']=$reply['uid'];
		$replydata['ctime']=$ctime;
		$replydata['mark']=$mark; 
		$replydata['content']=$content;
		$replydata['is_del']=$weiba_data['is_shenhe'];
		$rid=M('weiba_reply')->add($replydata);
		//
		M('weiba_post')->where(array('id'=>$post_id))->setInc('reply_all_count');
		M('weiba')->where(array('id'=>$article['weiba_id']))->setInc('allthread_count');
		
		$post_data['last_reply_time']=time();
		M('weiba_post')->where(array('id'=>$post_id))->save($post_data);
		$replydata['id']=$rid;
		$replydata['ctime']=time_format($ctime);
		//$data['is_shenhe']=$weiba_data['is_shenhe'];
		$data['ret']=1;
		$data['errmsg']='回复成功!';
		$userdata['usertag']=get_users_tag($userdata['uid'],$article['weiba_id']);
		$data['data']=$replydata; 
		$data['userdata']=$userdata;
		$this->ajaxReturn($data);
		
		
	}
	public function bbs($page_index=1,$page_size=30,$page_type=1,$weba_id='',$name='')
	{
		$this->wait();
		//获取用户信息
		$userdata=get_userinfo(0,false);
		
		//
		/* 
		if(isset($userdata['errcode']))
		{
			redirect(U('index/my',array('name'=>$name,'isrefush'=>1)));
		}
		else if($userdata['uid']>0)
		{
			$udata=M('user_login')->where('uid='.$userdata['uid'])->cache(true)->find();
			if($udata!=null)
			{
				$userdata=get_userinfo(1); 
			}
		}
	    */
	
		//
		//获取发布区域信息
		//$bbs=$this->bbs;
		if($weba_id==null||$weba_id==0)
		{
			$bbs=$this->bbs;
		}
		else
		{
			$bbs=D('Home/weiba')->get_weiba($weba_id);
		}
		if($name==DEFAULT_NAME)
		{
			$sf_admin=$this->is_admin($userdata['uid'],$bbs['id']);
			$sf_supadmin=$this->is_supadmin($userdata['uid'],$bbs['id']);
			if(!$sf_admin&&!$sf_supadmin)
			{
				redirect(U('index/allshelf',array('name'=>$name)));
			}
			 
		}
		//$bbs=D('Home/weiba')->get_bbs($this->token,'bbs');//dump($bbs);die;
		//$bbs=$this->bbs;
		$this->userdata=$userdata;
		$this->webdata=$bbs;
		
		//得到帖子
		
		
		
		$this->page_index=$page_index;
		$this->page_size=$page_size;
		$this->page_type=$page_type;
		addUserScore($this->webname,$userdata['uid'],0,$bbs['id']);
		if(IS_POST)
		{
			$list_data=$this->bbs_getdata($bbs['id'],$page_index,$page_size,$page_type,$userdata['uid']);
			$dsize=count($list_data);
	
			if($list_data!=null&&($dsize==intval($page_size)))
			{
				$page_index=$page_index+1;
			}
			
			foreach($list_data as &$li)
			{
				$li['usertag']=get_users_tag($li['post_uid'],$bbs['id']);
				$li['nickname']=str_urldecode_trim($li['nickname']);
				//$li['post_time']=time_format($li['post_time']);
				//$li['post_time']=time_format($li['last_reply_time']);
				$li['post_time']=format_date($li['last_reply_time']);
				if($li['describe']!=null)
				{
					$li['content']=$li['describe'];
				}
				else
				{
					$li['content']=str_get_describe($li['content']);
				}
				if($li['styletype']=='notice')
				{
					$li['styletype']='bbs';
					//$li['title']=str_get_describe($li['title'],$li['content'],50);
				} 
				if($li['jump_url']==null)
				{
					$li['jump_url']=U('index/content',array('id'=>$li['id']));
					
				}
				else
				{
					$li['is_link']=1;
				}
				//if($li['lock'])
			}
			//排序
			foreach($list_data as $li)
			{
				if($li['index_order']>=5)
				{
					$li_data_h[]=$li;
				}
				else
				{
					$li_data_p[]=$li;
				}
			}
			if(!Empty($li_data_h))
			{
				$list_data=array_merge($li_data_h,$li_data_p);
			}
			$this->list_data=$list_data;
			if($list_data==null)
			{
				$data['ret']=0;
				$data['errmsg']='已加载全部数据';
				
			}
			else
			{
				$data['ret']=1;
				$data['page_index']=$page_index;
				$data['page_size']=$page_size;
				$data['page_type']=$page_type;
				$data['userdata']=$this->userdata;
				$data['webdata']=$this->webdata;
				$data['list_data']=$list_data;
			}
			
			$this->ajaxReturn($data);
			
		}else
		{
			//子版块
			//子版块
			$hot_data=$this->bbs_getdata($bbs['id'],0,20,4,$userdata['uid']);
			if(count($hot_data)<20)
			{
				$hot_data=$this->bbs_getdata($bbs['id'],0,20,5,$userdata['uid']);
			}
			 
			$ndata;
			foreach($hot_data as &$li)
			{
				if($li['describe']!=null)
				{
					$li['content']=$li['describe'];
				}
				
				$li['title']=str_get_describe($li['title'],$li['content'],100,'');
				
				if($li['jump_url']==null)
				{
					$li['jump_url']=U('index/content',array('id'=>$li['id']));
					
				}
				else
				{
					$li['is_link']=1;
				}
				if($li['styletype']=='notice')
				{
					$li['color']='red';
					 
					$ndata[]=$li;
				}
				else
				{
					$li['styletype']='hot';
					$hdata[]=$li;
				}
			}
			$nc=count($ndata);
			$ict=0;
			if($nc<6)
			{
			   $this->hot_start_index=6;
			   $this->hot_page_index=(6- $nc)*2+$nc-1;
			   $this->hot_end_index=(6- $nc)*3+$nc-2;
			}
			else
			{
				$this->hot_start_index=$nc;
			    $this->hot_end_index=$nc;
				$this->hot_page_index=$nc;
			}

			$this->hot_data=$hot_data;
		}
		 
		$this->display();
	}
	public function login_check()
	{
		$data['ret']=0;
		$callback=GetCurUrl();
		$data['url']=U('index/login',array('name'=>$webname,'backurl'=>urlencode($callback)));
		$userdata=get_login_userinfo();
		if($userdata==null)
		{
			$data['ret']=1;
		}
		$this->ajaxReturn($data);
	}
	
	public function activity($id=0,$page_index=1,$page_size=30,$page_type=1)
	{
		$map['id']=$id;
	
		//$map['is_del']=0; 
		
		//获取context
		$list_data=M('weiba_post_view')->field ( true)->where ( $map )->find();
		
		
		
		
		if($list_data==null)
		{
			$this->error('帖子不存在!');
		}
		 
		$list_data['content']=str_replace('"/admin/Uploads/','"'.DEFAULT_FILE.'/Uploads/',$list_data['content']);
		if($list_data['jump_url']==null) 
		{
			$list_data['jump_url']=U('index/content',array('id'=>$list_data['id']));
		}
		else
		{
			$list_data['content']=$list_data['content'].'<a style="color:blue" href="'.$list_data['jump_url'].'">本文为转载，点此阅读原文</a>';
			 
		}
		if($list_data['styletype']=='chapter')
		{
			unset($map);
			$map['bookid']= intval( $list_data['bookid']);
			$map['is_del']=0;
			$map['chapterid']=intval($list_data['chapterid'])-1;
			$lastdata=M('weiba_post_view')->field('id')->where($map)->find();
		   
			if($lastdata!=null)
			{
				$this->lastchapter=U('index/content',array('id'=>$lastdata['id']));
			}
		 
			$map['chapterid']=$list_data['chapterid']+1;
			$nextdata=M('weiba_post_view')->field('id')->where($map)->find();
			if($nextdata!=null)
			{
				$this->nextchapter=U('index/content',array('id'=>$nextdata['id']));
			}
				
			$this->chapterlist=U('index/chapterlist',array('bookid'=>$list_data['bookid']));
			
			$book=M('weiba_book')->where(array('id'=>$list_data['bookid']))->find();
			if($book['index_title']==null)
			{
				$book['index_title']='('.$book['authorname'].')'.'_'.$book['bookname'];
			}
			$book_title='-'.$book['index_title'];
			$book_keyword=$book['bookname'].','.$book['authorname'].',';
			
			//$book_describe=$book['bookdescribe'].',';
			
			 
		}
		else if($list_data['styletype']=='activity')
		{
			
		}
		$this->imgurl=$list_data['headimgurl'];
	    $this->publicdata=$this->contextdata[$list_data['token']];
		$this->token=$list_data['token'];
		$this->webname=$this->publicdata['wechat'];
		$bbs=D('Home/weiba')->get_bbs($this->token,'bbs');
		$this->bbs=$bbs;
		if($book_title==null)
		{
			$book_title='_'.$bbs['weiba_name'];
		}
		if($list_data['title']==null)
		{
			$title=str_get_describe($list_data['title'],$list_data['content'],20);
		}
		else
		{
			$title=$list_data['title'];
		}
		$this->page_title=$title.$book_title;  
		$this->keywords=$book_keyword.$bbs['weiba_name'];
		
		$book_describe=str_get_describe($list_data['title'],$list_data['content'],200);
		
		$this->description=$book_describe.'——'.$bbs['intro'];	
		$this->page_index=$page_index;
		$this->page_size=$page_size;
		$this->page_type=$page_type;
		$this->list_data=$list_data;
		
		if(IS_POST)
		{
			$reply_data=$this->bbs_get_reply_data($id,$page_index,$page_size,$page_type);
			$dsize=count($reply_data);
			//dump($reply_data);die;
			if($reply_data!=null&&($dsize==intval($page_size)))
			{
				$page_index=$page_index+1;
			}
			$this->page_index=$page_index;
			foreach($reply_data as &$li)
			{
				$li['usertag']=get_users_tag($li['uid'],$bbs['id']);
				$li['nickname']=str_urldecode_trim($li['nickname']);
				$li['ctime']=time_format($li['ctime']);
				if($li['to_uid']>0&&$li['uid']!=$li['to_uid'])
				{
					$li['content']='<span style="color:blue">'.$li['mark'].': </span>'.$li['content'];
				} 
				foreach($li['subreply'] as &$l)
				{
					//$l['usertag']=get_users_tag($l['uid'],$bbs['id']);
					$l['nickname']=str_urldecode_trim($l['nickname']);
					$l['ctime']=format_date($l['ctime']);
				}
			}
			if($list_data==null)
			{
				$data['ret']=0;
				$data['errmsg']='已加载全部数据';
				
			}
			else
			{
				$data['ret']=1;
				$data['page_index']=$page_index;
				$data['page_size']=$page_size;
				$data['page_type']=$page_type;
				$data['userdata']=$this->userdata;
				$data['webdata']=$this->webdata;
				$data['reply_data']=$reply_data;
			}
			
			$this->ajaxReturn($data);
			
		}
		
		
		$this->display();
	}
	public function content($id=0,$page_index=1,$page_size=30,$page_type=1)
	{
		 
		$map['id']=$id;
	
		//$map['is_del']=0; 
		
		//获取context
		$list_data=M('weiba_post_view')->field ( true)->where ( $map )->find();
		
		
		
		
		if($list_data==null)
		{
			$this->error('帖子不存在!');
		}
		 
		/*
		if($list_data['is_del']==1)
		{
			$isadmin=I('isadmin',0);
			if($isadmin==0)
			{
				$this->error('帖子不存在或被删除!');
			}
			$userdata=get_userinfo();
			if(!$this->is_admin($userdata['uid'],$list_data['weiba_id'])&&!$this->is_supadmin($userdata['uid'],$list_data['weiba_id']))
			{
				$this->error('帖子不存在或被删除!');
			}
			
		}
		*/
		$list_data['content']=str_replace('"/admin/Uploads/','"'.DEFAULT_FILE.'/Uploads/',$list_data['content']);
		if($list_data['jump_url']==null) 
		{
			$list_data['jump_url']=U('index/content',array('id'=>$list_data['id']));
		}
		else
		{
			$list_data['content']=$list_data['content'].'<a style="color:blue" href="'.$list_data['jump_url'].'">本文为转载，点此阅读原文</a>';
			 
		}
		if($list_data['styletype']=='chapter')
		{
			unset($map);
			$map['bookid']= intval( $list_data['bookid']);
			$map['is_del']=0;
			$map['chapterid']=intval($list_data['chapterid'])-1;
			$lastdata=M('weiba_post_view')->field('id')->where($map)->find();
		   
			if($lastdata!=null)
			{
				$this->lastchapter=U('index/content',array('id'=>$lastdata['id']));
			}
		 
			$map['chapterid']=$list_data['chapterid']+1;
			$nextdata=M('weiba_post_view')->field('id')->where($map)->find();
			if($nextdata!=null)
			{
				$this->nextchapter=U('index/content',array('id'=>$nextdata['id']));
			}
				
			$this->chapterlist=U('index/chapterlist',array('bookid'=>$list_data['bookid']));
			
			$book=M('weiba_book')->where(array('id'=>$list_data['bookid']))->find();
			if($book['index_title']==null)
			{
				$book['index_title']='('.$book['authorname'].')'.'_'.$book['bookname'];
			}
			$book_title='-'.$book['index_title'];
			$book_keyword=$book['bookname'].','.$book['authorname'].',';
			
			//$book_describe=$book['bookdescribe'].',';
			
			 
		}
		else if($list_data['styletype']=='activity')
		{
			
		}
		$this->imgurl=$list_data['headimgurl'];
	    $this->publicdata=$this->contextdata[$list_data['token']];
		$this->token=$list_data['token'];
		$this->webname=$this->publicdata['wechat'];
		$bbs=D('Home/weiba')->get_bbs($this->token,'bbs');
		$this->bbs=$bbs;
		if($book_title==null)
		{
			$book_title='_'.$bbs['weiba_name'];
		}
		if($list_data['title']==null)
		{
			$title=str_get_describe($list_data['title'],$list_data['content'],20);
		}
		else
		{
			$title=$list_data['title'];
		}
		$this->page_title=$title.$book_title;  
		$this->keywords=$book_keyword.$bbs['weiba_name'];
		
		$book_describe=str_get_describe($list_data['title'],$list_data['content'],200);
		
		$this->description=$book_describe.'——'.$bbs['intro'];	
		
		$this->head_more='<meta property="og:type" content="bbs"/>
						<meta property="og:image" content="'.$list_data['headimgurl'].'"/>
						<meta property="og:release_date" content="'.time_format($list_data['post_time']).'"/>
						<!--选填-->
						<meta property="og:title" content="'.$this->page_title.'"/>
						<meta property="og:author" content="'.str_urldecode_trim($list_data['nickname']).'"/>
						<meta property="og:bbs:replay" content="'.$list_data['reply_all_count'].'"/>
						<meta property="og:description" content="'.$this->description.'"/>';
		
		
		
		$this->page_index=$page_index;
		$this->page_size=$page_size;
		$this->page_type=$page_type;
		$this->list_data=$list_data;
		
		if(IS_POST)
		{
			$reply_data=$this->bbs_get_reply_data($id,$page_index,$page_size,$page_type);
			$dsize=count($reply_data);
			//dump($reply_data);die;
			if($reply_data!=null&&($dsize==intval($page_size)))
			{
				$page_index=$page_index+1;
			}
			$this->page_index=$page_index;
			foreach($reply_data as &$li)
			{
				$li['usertag']=get_users_tag($li['uid'],$bbs['id']);
				$li['nickname']=str_urldecode_trim($li['nickname']);
				$li['ctime']=time_format($li['ctime']);
				if($li['to_uid']>0&&$li['uid']!=$li['to_uid'])
				{
					$li['content']='<span style="color:blue">'.$li['mark'].': </span>'.$li['content'];
				} 
				foreach($li['subreply'] as &$l)
				{
					//$l['usertag']=get_users_tag($l['uid'],$bbs['id']);
					$l['nickname']=str_urldecode_trim($l['nickname']);
					$l['ctime']=format_date($l['ctime']);
				}
			}
			if($list_data==null)
			{
				$data['ret']=0;
				$data['errmsg']='已加载全部数据';
				
			}
			else
			{
				$data['ret']=1;
				$data['page_index']=$page_index;
				$data['page_size']=$page_size;
				$data['page_type']=$page_type;
				$data['userdata']=$this->userdata;
				$data['webdata']=$this->webdata;
				$data['reply_data']=$reply_data;
			}
			
			$this->ajaxReturn($data);
			
		}
		
		
		$this->display();
	}
	public function my($isrefush=0)
	{
		$logintype='wxlogin';
		if($isrefush==1)
		{
			$logintype='none';  
		}
		$userdata=get_userinfo($isrefush,true,$logintype);
		//dump($userdata);
		//获取发布区域信息
		$bbs=D('Home/weiba')->get_bbs($this->token,'bbs');
		$this->userdata=$userdata; 
		$this->webdata=$bbs;
		addUserScore($this->webname,$userdata['uid'],0,$bbs['id']);
		$this->role=0;
		if($this->is_admin($userdata['uid'],$bbs['id']))
		{
			$this->role=1;
		}
	   if($this->is_supadmin($userdata['uid'],$bbs['id']))
		{
			$this->role=2;
		}
		 
		
		$this->page_title='个人中心_'.$bbs['weiba_name'];
		$this->keywords=$bbs['weiba_name'];
		$this->description=$bbs['intro'];	
		
		$this->display();
	}
	
	public function supadmin()
	{
		$this->display();
	}
	public function ptadmin()
	{
		$this->display();
	}
	public function set_blanklist()
	{
		
		$userdata=get_userinfo();
		$weiba_id=$this->bbs['id'];
		//判断用户是否有权限
		if(!$this->is_supadmin($userdata['uid'],$weiba_id)&&!$this->is_admin($userdata['uid'],$weiba_id))
		{
			$this->error('用户缺乏权限!',U('index/my'));
		}
		$map['weiba_id']=$weiba_id;
		// $map['cuserid']=$userdata['uid'];
		$blanklist=M('weiba_blanklist_view')->where($map)->select();
		foreach($blanklist as &$li)
		{
			$li['nickname']=str_urldecode_trim($li['nickname']);
		}
		$this->blanklist=$blanklist;
		$this->display();
	}
	public function set_admin()
	{
		$userdata=get_userinfo();
		$weiba_id=$this->bbs['id'];
		//判断用户是否有权限
		if(!$this->is_supadmin($userdata['uid'],$weiba_id))
		{
			$this->error('用户缺乏权限!',U('index/my'));
		}
		$admin_uid=explode(',',$this->bbs['admin_uid']);
		 if(is_array($admin_uid)){
		    $map['uid']=array('in',implode(',',$admin_uid));
		    $adminlist=M('user')->where($map)->order('uid')->select();
			foreach($adminlist as &$ad)
			{
				$ad['nickname']=str_urldecode_trim($ad['nickname']);
			}
			$this->adminlist=$adminlist;
	     }
		
		
		$this->display();
	}
	public function set_reply($weiba_id=0,$page_index=1,$page_size=30,$page_type=1)
	{
		$this->page_type=I('page_type',1);
		$weiba_id=I('weiba_id',$this->bbs['id']);
		$this->is_shenhe=$this->bbs['is_shenhe'];
		$userdata=get_userinfo();
		$post_uid=$userdata['uid'];
		if(IS_POST)
		{
			$map['weiba_id']=$weiba_id;
			if($page_type==1)//待审核
			{
				$map['is_del']=-1;
				$list_data=M('weiba_reply_view')->field ( true)->where ( $map )->page($pageindex,$pagesize)->select();
			}
			else if($page_type==2)//已审核
			{
				$map['is_del']=0;
				
				$list_data=M('weiba_reply_view')->field ( true)->where ( $map )->page($pageindex,$pagesize)->select();
			}
			else if($page_type==3)//已删除
			{
				$map['is_del']=1;
				$list_data=M('weiba_reply_view')->field ( true)->where ( $map )->page($pageindex,$pagesize)->select();
			}
			$dsize=count($list_data);
			if($list_data!=null&&($dsize==intval($page_size)))
			{
				$page_index=$page_index+1;
			}
			if($list_data==null)
			{
				$data['ret']=0;
				$data['errmsg']='已加载全部数据';
				
			}
			else
			{
				foreach($list_data as &$li)
				{
					$li['usertag']=get_users_tag($li['uid'],$this->bbs['id']);
					$li['nickname']=str_urldecode_trim($li['nickname']);
					$li['ctime']=time_format($li['ctime']);
					$li['content']=$li['content'];
					if($li['jump_url']==null)
					{
						$li['jump_url']=U('index/content',array('id'=>$li['post_id'],'isadmin'=>'1'));
						
					}
					else
					{  
						$li['jump_url']=$li['jump_url'].'&isadmin=1';
						$li['is_link']=1;
					}
				}
				$data['ret']=1;
				$data['page_index']=$page_index;
				$data['page_size']=$page_size;
				$data['page_type']=$page_type;
				$data['userdata']=$this->userdata;
				$data['webdata']=$this->webdata;
				$data['list_data']=$list_data;
			}
			
			$this->ajaxReturn($data);
		}
		
		$this->page_index=$page_index;
		$this->page_size=$page_size;
		$this->page_type=$page_type;
		$this->weiba_id=$weiba_id;
		$this->display();
	}
	public function set_article($weiba_id=0,$page_index=1,$page_size=30,$page_type=1)
	{
		$this->page_type=I('page_type',1);
		$weiba_id=I('weiba_id',$this->bbs['id']);
		$this->is_shenhe=$this->bbs['is_shenhe'];
		$userdata=get_userinfo();
		$post_uid=$userdata['uid'];
		if(IS_POST)
		{
			$map['weiba_id']=$weiba_id;
			if($page_type==1)//待审核
			{
				$map['is_del']=-1;
				$list_data=M('weiba_post_view')->field ( true)->where ( $map )->page($pageindex,$pagesize)->select();
			}
			else if($page_type==2)//已审核
			{
				$map['is_del']=0;
				
				$list_data=M('weiba_post_new_view')->field ( true)->where ( $map )->page($pageindex,$pagesize)->select();
			}
			else if($page_type==3)//已删除
			{
				$map['is_del']=1;
				$list_data=M('weiba_post_view')->field ( true)->where ( $map )->page($pageindex,$pagesize)->select();
			}
			$dsize=count($list_data);
			if($list_data!=null&&($dsize==intval($page_size)))
			{
				$page_index=$page_index+1;
			}
			if($list_data==null)
			{
				$data['ret']=0;
				$data['errmsg']='已加载全部数据';
				
			}
			else
			{
				foreach($list_data as &$li)
				{
					$li['usertag']=get_users_tag($li['post_uid'],$li['weiba_id']);
					$li['nickname']=str_urldecode_trim($li['nickname']);
					$li['post_time']=time_format($li['post_time']);
					$li['content']=str_get_describe($li['content']);
					if($li['jump_url']==null)
					{
						$li['jump_url']=U('index/content',array('id'=>$li['id'],'isadmin'=>'1'));
						
					}
					else
					{  
						$li['jump_url']=$li['jump_url'].'&isadmin=1';
						$li['is_link']=1;
					}
				}
				$data['ret']=1;
				$data['page_index']=$page_index;
				$data['page_size']=$page_size;
				$data['page_type']=$page_type;
				$data['userdata']=$this->userdata;
				$data['webdata']=$this->webdata;
				$data['list_data']=$list_data;
			}
			
			$this->ajaxReturn($data);
		}
		
		$this->page_index=$page_index;
		$this->page_size=$page_size;
		$this->page_type=$page_type;
		$this->weiba_id=$weiba_id;
		$this->display();
	}
	public function login($name='xiaoheiwu')
	{
		$backurl=I('backurl');
		//dump($backurl);die;
		//$backurl=urldecode( $backurl);
	    get_userinfo(0,true,'none');
		redirect(urldecode( $backurl));
		/*
		if(IS_POST)
		{
			$username=I('post.username');
			$userpwd=I('post.password');
			$map['login_name']=$username;
			$map['password']=think_weiphp_md5($userpwd);
			$userdata=M('user')->where($map)->find();
			if($userdata==null)
			{
				$rs['ret']=0;
				$rs['errmsg']='用户名或密码错误!';
			}
			else
			{
				$userdata['nickname']=str_urldecode_trim($userdata['nickname']);
				set_userinfo($userdata);
				$rs['ret']=1;
				$rs['errmsg']='登陆成功!';
			}
			$this->ajaxReturn($rs);
		}
		 $backurl=I('backurl',U('index/index',array('name'=>I('name','xiaoheiwu'))));
	
		 $backurl=urldecode( $backurl);
		 if(session('backurl')==null)
		 {
			 session('backurl',$backurl);
		 }
		if(isWeixinBrowser())
		{
			$userdata=get_userinfo(0,false);
			if($userdata['uid']==null)
			{
				$userdata=get_userinfo(1);
			}
			else
			{
				if(session('backurl')!=null)
				{
					 $backurl=session('backurl');
					 session('backurl',null);
				}
				else
				{
					$backurl=U('index/my',array('name'=>$name));
				}
				redirect($backurl);
			}
	
		}
		 $backurl=str_replace('isrefush','refush',$backurl);
		 $this->backurl=$backurl;
		 $this->display();
	    */
	}
	
	public function bbs_getdata($weiba_id,$pageindex=0,$pagesize=30,$page_type=1,$post_uid=0)
	{
		if($post_uid==null)
		{
			$post_uid=0;
		}
		$map['weiba_id']=$weiba_id;//->cache(true)
		$map['is_del']=0;
		
		if($page_type==1)
		{
			$condition='weiba_id='.$weiba_id.' AND styletype<>"chapter" AND  (is_del=0 OR post_uid='.$post_uid.')';
			
			$data=M('weiba_post_view')->field ( true)->where ( $condition )->page($pageindex,$pagesize)->select();
			
			//$map['styletype']= array('neq','chapter');
			//$data=M('weiba_post_view')->field ( true)->where ( $map )->page($pageindex,$pagesize)->select();
		}
		else if($page_type==2)
		{
			 
			
			$condition='weiba_id='.$weiba_id.' AND (is_del=0  OR post_uid='.$post_uid.')';
			$data=M('weiba_post_hot_view')->field ( true)->where ( $condition )->where($condition)->page($pageindex,$pagesize)->select();
			
			//$data=M('weiba_post_hot_view')->field ( true)->where ( $map )->page($pageindex,$pagesize)->select();
		}
		else if($page_type==4)
		{
			 
			
			$condition='weiba_id='.$weiba_id.' AND (is_del=0  OR post_uid='.$post_uid.')';
			$data=M('weiba_post_new_hot_view')->field ( true)->where ( $condition )->where($condition)->page($pageindex,$pagesize)->select();
			
			//$data=M('weiba_post_hot_view')->field ( true)->where ( $map )->page($pageindex,$pagesize)->select();
		}
		else if($page_type==5)
		{
			 
			
			$condition='weiba_id='.$weiba_id.' AND (is_del=0  OR post_uid='.$post_uid.')';
			$data=M('weiba_post_new_hot_all_view')->field ( true)->where ( $condition )->where($condition)->page($pageindex,$pagesize)->cache(true)->select();
			
			//$data=M('weiba_post_hot_view')->field ( true)->where ( $map )->page($pageindex,$pagesize)->select();
		}
		else if($page_type==0)
		{
			$map['post_uid']=$post_uid;
			$data=M('weiba_post_view')->field ( true)->where ( $map )->page($pageindex,$pagesize)->select();
			
		}
		else if($page_type==3) 
		{
			$map['digest']=1;
			$data=M('weiba_post_view')->field ( true)->where ( $map )->page($pageindex,$pagesize)->select();
			
		}
		//limit($pageindex*$pagesize,($pageindex+1)*$pagesize)->select();
	    /*
		if(IS_POST)
		{
			$rdata['listdata']=$data;
			$rdata['ret']=1;
			$this->ajaxReturn($rdata);
		}
		else
		{
			
		}*/
		return $data;
		
	}
	public function bbs_get_reply_data($post_id=0,$pageindex=0,$pagesize=30,$page_type=1)
	{
		$map['post_id']=$post_id;//->cache(true)
			$map['is_del']=0;
			//$map['to_reply_id']=0;
			if($page_type==1)
			{
				$data=M('weiba_reply_view')->field ( true)->where ( $map )->page($pageindex,$pagesize)->select();
			}
			else if($page_type==2)
			{
				$data=M('weiba_reply_hot_view')->field ( true)->where ( $map )->page($pageindex,$pagesize)->select();
			}
		foreach($data as &$li)
		{
			unset($map);
			$map['to_reply_id']=$li['reply_id'];
			$map['is_del']=0;
			$subreply=M('weiba_reply_view')->where($map)->limit(0,5)->order('ctime')->select();
			$li['subreply']=$subreply;
			
		}	
		return $data;
		
	}
	public function articleinit($id=0)
	{
		$data['ret']=0;
		$data['errmsg']='';
		$article=M('weiba_post')->where(array('id'=>$id))->find();
		if($article==null)
		{
			$data['errmsg']='帖子不存在!';
			if(IS_POST)
			{
				$this->ajaxReturn($data);
			}
		}
		$userdata=get_userinfo();
		if($userdata==null)
		{
			$userdata['uid']=-1;
		}
		$manage=array();
		$sf_supadmin=$this->is_supadmin($userdata['uid'],$article['weiba_id']);
		//判断是否超管
		if($sf_supadmin)
		{
			//判断置顶
			if($article['top']==0)
			{
				$manage[]='article_top';
			}
			else
			{
				$manage[]='article_untop';
			}
			//加精
			if($article['digest']==0)
			{
				$manage[]='article_digest';
			}
			else
			{
				$manage[]='article_undigest'; 
			}
			
			if($article['styletype']=='notice')
			{
				$manage[]='article_unnotice';
			}
			else
			{
				$manage[]='article_notice';
			}
			$manage[]='article_down';
			//$manage[]='article_up';
		}
		
		//判断收藏状态
		$map['uid']=$userdata['uid'];
		$map['post_id']=$id;
		$map['post_type']=0;
		//$map['weiba_id']=$article['weiba_id'];
		//$map['post_uid']=$article['post_uid'];
		$sc=M('weiba_favorite')->where($map)->find();
		if($sc==null)
		{
			$manage[]='article_favorite';
		}
		else
		{
			$manage[]='article_unfavorite';
		}
		//判断是否有删除权限
		//发帖人和管理员有删除权限
		$sf_zj=false;
		if($userdata['uid']==$article['post_uid'])
		{
			$sf_zj=true;
		}
		$sf_admin=$this->is_admin($userdata['uid'],$article['weiba_id']);
		if($sf_admin||$sf_supadmin)
		{
			if($article['is_del']==0)
			{
				$manage[]='article_del';
			}
			else if($article['is_del']==1)
			{
				if($sf_admin||$sf_supadmin)
				{
					$manage[]='article_undel';
				}
			}
			else  if($article['is_del']==-1)
			{
				$manage[]='article_del';
				$manage[]='article_shenhe';
			}
		}
		if($sf_zj||$sf_supadmin)
		{
			 $manage[]='article_realdel';	
		}
		//判断点赞状态
		unset($map);
		$map['uid']=$userdata['uid'];
		$map['post_id']=$id;
		$dz=M('weiba_post_digg')->where($map)->find();
		if($dz==null)
		{
			$manage[]='article_digg';
		}
		else
		{
			$manage[]='article_undigg';
		}
		//判断是否可以封禁用户
		if($sf_admin||$sf_supadmin)
		{
			$manage[]='article_up';
			$sf_supadmin_user=$this->is_supadmin($article['post_uid'],$article['weiba_id']);
			if(!$sf_supadmin_user)
			{
				 //查询用户封禁状态
				 unset($map);
				$map['userid']=$article['post_uid'];
				$map['weiba_id']=$article['weiba_id'];
				$map['status']=1;
				$us=M('weiba_bbs_users')->where($map)->find();
				if($us==null)
				 {
					$manage[]='user_limit';	
				 }
				 else
				 {
					 $manage[]='user_unlimit';	
				 }
				
				 
			}
		}
		$manage[]='article_reply';
		$data['manage']=$manage;
		
		
		//热门评论
		unset($map);
		//$map['weiba_id']=$article['weiba_id'];
		$map['post_id']=$article['id'];
		$map['is_del']=0;
		$replyhot=M('weiba_reply_hot_view')->where($map)->find();
		if($replyhot!=null)
		{
			$replyhot['ctime']=time_format($replyhot['ctime']);
			$replyhot['nickname']=str_urldecode_trim($replyhot['nickname']);
			$replyhot['jump_url']=U('index/content',array('id'=>$article['id'],'reply_id'=>$replyhot['reply_id']));
		}
		$data['hotreply']=$replyhot;
		//作者评论
		
		
		
		
		$data['ret']=1;
		if(IS_POST)
		{
			$this->ajaxReturn($data);
		}
	}
	
	public function replyinit($id=0)
	{
		$data['ret']=0;
		$data['errmsg']='';
		$article=M('weiba_reply')->where(array('reply_id'=>$id))->find();
		if($article==null)
		{
			$data['errmsg']='回复不存在或被删除!';
			if(IS_POST)
			{
				$this->ajaxReturn($data);
			}
		}
		$userdata=get_userinfo();
		if($userdata==null)
		{
			$userdata['uid']=-1;
		}
		$manage=array();
		//判断是否超管
		$sf_supadmin=$this->is_supadmin($userdata['uid'],$article['weiba_id']);
		if($sf_supadmin)
		{
			//判断置顶
			if($article['top']==0)
			{
				$manage[]='article_top';
			}
			else
			{
				$manage[]='article_untop';
			}
			$manage[]='article_down';
			
		}
		/*
		//判断收藏状态
		$map['uid']=$userdata['uid'];
		$map['post_id']=$id;
		$map['post_type']=1;

		$sc=M('weiba_favorite')->where($map)->find();
		if($sc==null)
		{
			$manage[]='article_favorite';
		}
		else
		{
			$manage[]='article_unfavorite';
		}
		*/
		//判断是否有删除权限
		//发帖人和管理员有删除权限
		$sf_zj=false;
		if($userdata['uid']==$article['uid'])
		{
			$sf_zj=true;
		}
		$sf_admin=$this->is_admin($userdata['uid'],$article['weiba_id']);
		if($sf_admin||$sf_supadmin)
		{
			if($article['is_del']==0)
			{
				$manage[]='article_del';
			}
			else if($article['is_del']==1)
			{
				$manage[]='article_undel';
			}
			else  if($article['is_del']==-1)
			{
				$manage[]='article_del';
				$manage[]='article_shenhe';
			}
		}
		if($sf_zj||$sf_supadmin)
		{
			 $manage[]='article_realdel';	
		}
		//判断点赞状态
		unset($map);
		$map['uid']=$userdata['uid'];
		$map['row_id']=$id;
		$dz=M('weiba_reply_digg')->where($map)->find();
		if($dz==null)
		{
			$manage[]='article_digg';
		}
		else
		{
			$manage[]='article_undigg';
		}
		//判断是否可以封禁用户
		if($sf_admin||$sf_supadmin)
		{
			$manage[]='article_up';
			$sf_supadmin_user=$this->is_admin($article['uid'],$article['weiba_id']);
			if(!$sf_supadmin_user)
			{
				//查询用户封禁状态
				unset($map);
				$map['userid']=$article['uid'];
				$map['weiba_id']=$article['weiba_id'];
				$map['status']=1;
				$us=M('weiba_bbs_users')->where($map)->find();
				if($us==null)
				 {
					$manage[]='user_limit';	
				 }
				 else
				 {
					 $manage[]='user_unlimit';	
				 }
			}
		}
		$manage[]='article_reply';
		$data['manage']=$manage;
		

		$data['ret']=1;
		if(IS_POST)
		{
			$this->ajaxReturn($data);
		}
		
	}
	function is_supadmin($uid,$weiba_id)
	{
		if($uid==666||$uid==110||$uid==814)
		{
			return true;
		}
		$is_ad=false;
		$weiba=M('weiba')->where(array('id'=>$weiba_id))->find();
		if($weiba!=null)
		{
			$admin_uid=$weiba['supadmin_uid'];
			$admin_uid=explode(',',$admin_uid);
		  if(is_array($admin_uid))
		  {
			  foreach($admin_uid as $admin)
			  {
				  if($admin==$uid)
				  {
					  $is_ad=true;
					  break;
				  }
			  }
		  }
		}
		return $is_ad;
	}
	function is_admin($uid,$weiba_id)
	{
		$is_ad=false;
		$weiba=M('weiba')->where(array('id'=>$weiba_id))->find();
		if($weiba!=null)
		{
			$admin_uid=$weiba['admin_uid'];
			$admin_uid=explode(',',$admin_uid);
		  if(is_array($admin_uid))
		  {
			  foreach($admin_uid as $admin)
			  {
				  if($admin==$uid)
				  {
					  $is_ad=true;
					  break;
				  }
			  }
		  }
		}
		return $is_ad;
	}
	function is_article_del($uid,$article)
	{
		$is_del=false;
		if($uid!=$article['post_uid'])
		{
			if($this->is_admin($uid,$article['weiba_id']))
			{
				 $is_del=true;
			}
		}
		else
		{
			$is_del=true;
		}
		return $is_del;
	}
	
	public function article_event($id=0,$weiba_id=0,$event_type='',$token='',$menu_type='article',$name='')
	{
		$weiba_log=null;
		$islog=false;
		//$weiba_log['type']=$event_type.'|'.$menu_type;
		if($token=='')
		{
			$token=$this->token;
		}
		if($name==null)
		{
			$name=$this->webname;
		}
		$userdata=get_userinfo();
		if(!$userdata)
		{
			$data['ret']=0;
		
			$data['errmsg']=get_login($name,'用户未登录',$_SERVER['HTTP_REFERER']);
			if($event_type!='weiba_click'&&$event_type!='article_click')
			{
				$this->ajaxReturn($data);
			}
			 
		}
		
		$weiba_id=0;
		if($this->bbs['id']!=null)
		{
			$weiba_id=$this->bbs['id'];
			$weiba_log['weiba_id']=$weiba_id;
		}
		if($userdata['uid']==null)
		{
			$userdata['uid']=0;
		}
		$weiba_log['uid']=$userdata['uid'];
		$data;
		$map;
		if($event_type=='article_favorite')
		{
			if($menu_type=='article')
			{
				$map['post_type']=0;
			}
			else if($menu_type=='reply')
			{
				$map['post_type']=1;
			}
			$map['uid']=$userdata['uid'];
			$map['post_id']=$id;
			
			$favorite=M('weiba_favorite');
			$fdata=$favorite->where($map)->find();
			if($fdata==null)
			{
				$fdata['uid']=$userdata['uid'];
				$fdata['post_id']=$id;
				$fdata['post_type']=$map['post_type'];
				$fdata['favorite_time']=time();
				$fdata['weiba_id']=$weiba_id;
				$favorite->add($fdata);
			}
			$data['ret']=1;
			$data['errmsg']='收藏成功!';
			
			
		}
		else if($event_type=='article_unfavorite')
		{
			unset($map);
			if($menu_type=='article')
			{
				$map['post_type']=0;
			}
			else if($menu_type=='reply')
			{
				$map['post_type']=1;
			}
			$map['uid']=$userdata['uid'];
			$map['post_id']=$id;
			$favorite=M('weiba_favorite');
			$fdata=$favorite->where($map)->delete();
			$data['ret']=1;
			$data['errmsg']='取消收藏成功!';
			
		}
		
		else if($event_type=='article_realdel')
		{
			$islog=true;
			if($menu_type=='article')
			{
			  
				//判断是否有删除权限
				$article=M('weiba_post')->where(array('id'=>$id))->find();
				$sf_zj=false;
				if($userdata['uid']==$article['post_uid'])
				{
					$sf_zj=true;
				}
				$sf_admin=$this->is_admin($userdata['uid'],$article['weiba_id']);
				$sf_supadmin=$this->is_supadmin($userdata['uid'],$article['weiba_id']);
				
				if($sf_zj||$sf_admin||$sf_supadmin)
				{
				 
					M('weiba_post')->where(array('id'=>$id))->delete();
					$data['ret']=1;
					$data['errmsg']='永久删除成功!';
				}
				else
				{
					$data['ret']=0;
					$data['errmsg']='删除失败,您缺乏权限！';
				}
				$weiba_log['post_id']=$id;
			}
			else if($menu_type=='reply')
			{
				
				//判断是否有删除权限
				$article=M('weiba_reply')->where(array('reply_id'=>$id))->find();
				$post_article=M('weiba_post')->where(array('id'=>$article['post_id']))->find();;
				$sf_zj=false;
				if($userdata['uid']==$article['uid'])
				{
					$sf_zj=true;
				}
				$sf_admin=$this->is_admin($userdata['uid'],$post_article['weiba_id']);
				$sf_supadmin=$this->is_supadmin($userdata['uid'],$post_article['weiba_id']);
				if($sf_zj||$sf_admin||$sf_supadmin)
				{
				 
					M('weiba_reply')->where(array('reply_id'=>$id))->delete();
					M('weiba_post')->where(array('id'=>$article['post_id']))->setDec('reply_all_count');
					$data['ret']=1;
					$data['errmsg']='永久删除成功!';
				}
				else
				{
					$data['ret']=0;
					$data['errmsg']='删除失败,您缺乏权限！';
				}
				$weiba_log['reply_id']=$id;
			}
			
		}
		else if($event_type=='article_del')
		{
			$islog=true;
			if($menu_type=='article')
			{
			
				//判断是否有删除权限
				$article=M('weiba_post')->where(array('id'=>$id))->find();
				$sf_zj=false;
				if($userdata['uid']==$article['post_uid'])
				{
					$sf_zj=true;
				}
				$sf_admin=$this->is_admin($userdata['uid'],$article['weiba_id']);
				$sf_supadmin=$this->is_supadmin($userdata['uid'],$article['weiba_id']);
				if($sf_zj||$sf_admin||$sf_supadmin)
				{
					unset($map);
					$map['is_del']=1;
					M('weiba_post')->where(array('id'=>$id))->save($map);
					$data['ret']=1;
					$data['errmsg']='屏蔽成功!';
				}
				else
				{
					$data['ret']=0;
					$data['errmsg']='屏蔽失败,您缺乏权限！';
				}
				$weiba_log['post_id']=$id;
			}
			else if($menu_type=='reply')
			{
				
				//判断是否有删除权限
				$article=M('weiba_reply')->where(array('reply_id'=>$id))->find();
				$post_article=M('weiba_post')->where(array('id'=>$article['post_id']))->find();;
				$sf_zj=false;
				if($userdata['uid']==$article['uid'])
				{
					$sf_zj=true;
				}
				$sf_admin=$this->is_admin($userdata['uid'],$post_article['weiba_id']);
				$sf_supadmin=$this->is_supadmin($userdata['uid'],$post_article['weiba_id']);
				if($sf_zj||$sf_admin||$sf_supadmin)
				{
					unset($map);
					$map['is_del']=1;
					M('weiba_reply')->where(array('reply_id'=>$id))->save($map);
					$data['ret']=1;
					$data['errmsg']='屏蔽成功!';
				}
				else
				{
					$data['ret']=0;
					$data['errmsg']='屏蔽失败,您缺乏权限！';
				}
				$weiba_log['reply_id']=$id;
			}
			
		}
		 else if($event_type=='article_undel')
		 {
			 $islog=true;
			 if($menu_type=='article')
			{
			
				//判断是否有删除权限
				$article=M('weiba_post')->where(array('id'=>$id))->find();
				$sf_zj=false;
				if($userdata['uid']==$article['post_uid'])
				{
					$sf_zj=true;
				}
				$sf_admin=$this->is_admin($userdata['uid'],$article['weiba_id']);
				$sf_supadmin=$this->is_supadmin($userdata['uid'],$article['weiba_id']);
				if($sf_zj||$sf_admin||$sf_supadmin)
				{
					unset($map);
					$map['is_del']=0;
					M('weiba_post')->where(array('id'=>$id))->save($map);
					$data['ret']=1;
					$data['errmsg']='撤销屏蔽成功!';
				}
				else
				{
					$data['ret']=0;
					$data['errmsg']='撤销屏蔽失败,您缺乏权限！';
				}
				$weiba_log['post_id']=$id;
			}
			else if($menu_type=='reply')
			{
				
				//判断是否有删除权限
				$article=M('weiba_reply')->where(array('reply_id'=>$id))->find();
				$post_article=M('weiba_post')->where(array('id'=>$article['post_id']))->find();;
				$sf_zj=false;
				if($userdata['uid']==$article['uid'])
				{
					$sf_zj=true;
				}
				$sf_admin=$this->is_admin($userdata['uid'],$post_article['weiba_id']);
				$sf_supadmin=$this->is_supadmin($userdata['uid'],$post_article['weiba_id']);
				if($sf_zj||$sf_admin||$sf_supadmin)
				{
					unset($map);
					$map['is_del']=0;
					M('weiba_reply')->where(array('reply_id'=>$id))->save($map);
					$data['ret']=1;
					$data['errmsg']='撤销屏蔽成功!';
				}
				else
				{
					$data['ret']=0;
					$data['errmsg']='撤销屏蔽失败,您缺乏权限！';
				}
				$weiba_log['reply_id']=$id;
			}
			 
		 }
		 else if($event_type=='article_digest')
		 {
			 $islog=true;
				$article=M('weiba_post')->where(array('id'=>$id))->find();
				$sf_supadmin=$this->is_supadmin($userdata['uid'],$article['weiba_id']);
				if($sf_supadmin)
				{
					unset($map);
					$map['digest']=1;
					M('weiba_post')->where(array('id'=>$id))->save($map);
					$data['ret']=1;
					$data['errmsg']='加精成功!'; 
				}
				$weiba_log['post_id']=$id;
		 }
		  else if($event_type=='article_undigest')
		 {
			 $islog=true;
				$article=M('weiba_post')->where(array('id'=>$id))->find();
				$sf_supadmin=$this->is_supadmin($userdata['uid'],$article['weiba_id']);
				if($sf_supadmin)
				{
					unset($map);
					$map['digest']=0;
					M('weiba_post')->where(array('id'=>$id))->save($map);
					$data['ret']=1;
					$data['errmsg']='取消精华成功!'; 
				}
				$weiba_log['post_id']=$id;
		 }
		  else if($event_type=='article_shenhe')
		 {
			 $islog=true;
			 if($menu_type=='article')
			{
			
				//判断是否有删除权限
				$article=M('weiba_post')->where(array('id'=>$id))->find();
				$sf_admin=$this->is_admin($userdata['uid'],$article['weiba_id']);
				$sf_supadmin=$this->is_supadmin($userdata['uid'],$article['weiba_id']);
				if($sf_admin||$sf_supadmin)
				{
					unset($map);
					$map['is_del']=0;
					M('weiba_post')->where(array('id'=>$id))->save($map);
					$data['ret']=1;
					$data['errmsg']='审核成功!'; 
				}
				else
				{
					$data['ret']=0;
					$data['errmsg']='审核失败,您缺乏权限！';
				}
				$weiba_log['post_id']=$id;
			}
			else if($menu_type=='reply')
			{
				$article=M('weiba_reply')->where(array('reply_id'=>$id))->find();
				$post_article=M('weiba_post')->where(array('id'=>$article['post_id']))->find();
				$sf_admin=$this->is_admin($userdata['uid'],$post_article['weiba_id']);
				$sf_supadmin=$this->is_supadmin($userdata['uid'],$post_article['weiba_id']);
				if($sf_admin||$sf_supadmin)
				{
					unset($map);
					$map['is_del']=0;
					M('weiba_reply')->where(array('reply_id'=>$id))->save($map);
					$data['ret']=1;
					$data['errmsg']='审核成功!';
				}
				else
				{
					$data['ret']=0;
					$data['errmsg']='审核失败,您缺乏权限！';
				}
				$weiba_log['reply_id']=$id;
			}
			
		 }
		else if($event_type=='article_digg')
		{
			
			if($menu_type=='article')
			{
				unset($map);
				$map['uid']=$userdata['uid'];
				$map['post_id']=$id;
				$dz=M('weiba_post_digg')->where($map)->find();
				if($dz==null)
				{
					$map['cTime']=time();
					M('weiba_post_digg')->add($map);
					M('weiba_post')->where('id='.$id)->setInc('praise');
				}
				$data['ret']=1;
				$data['errmsg']='点赞成功!';
			}
			else if($menu_type=='reply')
			{
				unset($map);
				$map['uid']=$userdata['uid'];
				$map['row_id']=$id;
				$dz=M('weiba_reply_digg')->where($map)->find();
				if($dz==null)
				{
					$map['cTime']=time();
					M('weiba_reply_digg')->add($map);
					M('weiba_reply')->where('reply_id='.$id)->setInc('digg_count');
				}
				$data['ret']=1;
				$data['errmsg']='点赞成功!';
			}
			
		}
		else if($event_type=='article_undigg')
		{
			if($menu_type=='article')
			{
				unset($map);
				$map['uid']=$userdata['uid'];
				$map['post_id']=$id;
				$dz=M('weiba_post_digg')->where($map)->find();
				if($dz!=null)
				{
					M('weiba_post_digg')->where($map)->delete();
					M('weiba_post')->where('id='.$id)->setDec('praise');
				}
				
				$data['ret']=1;
				$data['errmsg']='取消点赞成功!';
			}
			else if($menu_type=='reply')
			{
				unset($map);
				$map['uid']=$userdata['uid'];
				$map['row_id']=$id;
				$dz=M('weiba_reply_digg')->where($map)->find();
				if($dz!=null)
				{
					M('weiba_reply_digg')->where($map)->delete();
					M('weiba_reply')->where('reply_id='.$id)->setDec('digg_count');
				}
				
				$data['ret']=1;
				$data['errmsg']='取消点赞成功!';
			}
		}
		else if($event_type=='article_top')
		{
			$islog=true;
			//判断权限
			if($this->is_supadmin($userdata['uid'],$weiba_id))
			{
				unset($map);
				if($menu_type=='article')
				{
					$map['top']=1;
					$map['top_time']=time();
					//M('weiba_post')->where(array('id'=>$id))->setInc('top');
					M('weiba_post')->where(array('id'=>$id))->save($map);
					$data['ret']=1;
					$data['errmsg']='置顶成功!';
					$weiba_log['post_id']=$id;
				}
				else if($menu_type=='reply')
				{
					$map['top']=1;
					M('weiba_reply')->where(array('reply_id'=>$id))->save($map);
					$data['ret']=1;
					$data['errmsg']='置顶成功!';
					$weiba_log['reply_id']=$id;
				}
			}
			else
			{
				$data['ret']=0;
				$data['errmsg']='缺乏权限!';
			}
			
		}
		else if($event_type=='article_untop')
		{
			$islog=true;
			//判断权限
			if($this->is_supadmin($userdata['uid'],$weiba_id))
			{
				unset($map);
				if($menu_type=='article')
				{
					$map['top']=0;
					$map['top_time']=0;
					M('weiba_post')->where(array('id'=>$id))->save($map);
					$data['ret']=1;
					$data['errmsg']='取消置顶成功!';
					$weiba_log['post_id']=$id;
				}
				else if($menu_type=='reply')
				{
					$map['top']=0;
					M('weiba_reply')->where(array('reply_id'=>$id))->save($map);
					$data['ret']=1;
					$data['errmsg']='取消置顶成功!';
					$weiba_log['reply_id']=$id;
				}
			}
			else
			{
				$data['ret']=0;
				$data['errmsg']='缺乏权限!';
			}
			
		}
		else if($event_type=='article_down')
		{
			$islog=true;
			//判断权限
			if($this->is_supadmin($userdata['uid'],$weiba_id))
			{
				unset($map);
				if($menu_type=='article')
				{
					//$map['top']=0;
					//$map['last_reply_time']=;
					$pda=M('weiba_post')->where(array('id'=>$id))->find();
					if($pda['index_order']>0)
					{
						$map['index_order']=0;
						$map['top_time']=0;
						M('weiba_post')->where(array('id'=>$id))->save($map);
					}
					else
					{
						M('weiba_post')->where(array('id'=>$id))->setDec('last_reply_time',86400/2);
					}
					
					$data['ret']=1;
					$data['errmsg']='沉帖成功!';
					$weiba_log['post_id']=$id;
				}
				else if($menu_type=='reply')
				{
					//$map['top']=-1;
					M('weiba_reply')->where(array('reply_id'=>$id))->setDec('top');
					$data['ret']=1;
					$data['errmsg']='沉帖成功!';
					$weiba_log['reply_id']=$id;
				}
			}
			else
			{
				$data['ret']=0;
				$data['errmsg']='缺乏权限!';
			}
			 
		}
		else if($event_type=='article_up')
		{
			$islog=true;
			//判断权限
			if($this->is_supadmin($userdata['uid'],$weiba_id))
			{
				unset($map);
				if($menu_type=='article')
				{
					//$map['top']=0;
					//$map['last_reply_time']=;
					$map['top_time']=time();
					M('weiba_post')->where(array('id'=>$id))->save($map);
					M('weiba_post')->where(array('id'=>$id))->setInc('index_order');
					$data['ret']=1;
					$data['errmsg']='顶帖成功!';
					$weiba_log['post_id']=$id;
				}
				else if($menu_type=='reply')
				{
					//$map['top']=-1;
					M('weiba_reply')->where(array('reply_id'=>$id))->setInc('top');
					$data['ret']=1;
					$data['errmsg']='顶帖成功!';
					$weiba_log['reply_id']=$id;
				}
			}
			else
			{
				$data['ret']=0;
				$data['errmsg']='缺乏权限!';
			}
			 
		}
		else if($event_type=='article_notice')
		{
			$islog=true;
			//判断权限
			if($this->is_supadmin($userdata['uid'],$weiba_id))
			{
				unset($map);
				if($menu_type=='article')
				{
					//$map['mark']='notice';
					$map['styletype']='notice';
					M('weiba_post')->where(array('id'=>$id))->save($map);
					$data['ret']=1;
					$data['errmsg']='设为公告成功!';
					$weiba_log['post_id']=$id;
				}
				 
			}
			else
			{
				$data['ret']=0;
				$data['errmsg']='缺乏权限!';
			}
			
		}
		else if($event_type=='article_unnotice')
		{
			$islog=true;
			//判断权限
			if($this->is_supadmin($userdata['uid'],$weiba_id))
			{
				unset($map);
				if($menu_type=='article')
				{
					//$map['mark']='notice';
					$map['styletype']='bbs';
					M('weiba_post')->where(array('id'=>$id))->save($map);
					$data['ret']=1;
					$data['errmsg']='取消公告成功!';
					$weiba_log['post_id']=$id;
				}
				 
			}
			else
			{
				$data['ret']=0;
				$data['errmsg']='缺乏权限!';
			}
			$weiba_log['to_id']=$id;
		}
		else if($event_type=='user_limit')
		{
			$islog=true;
			if($menu_type=='article')
			{
				$article=M('weiba_post')->where(array('id'=>$id))->find();
				$post_uid=$article['post_uid'];
				$weiba_id=$article['weiba_id'];
			}
			else if($menu_type=='reply')
			{
				$article=M('weiba_reply')->where(array('reply_id'=>$id))->find();
				$post_article=M('weiba_post')->where(array('id'=>$article['post_id']))->find();
				$weiba_id=$post_article['weiba_id'];
				$post_uid=$article['uid'];
			
			}
			//判断是否可以封禁用户
			$sf_admin=$this->is_admin($userdata['uid'],$weiba_id);
			$sf_supadmin=$this->is_supadmin($userdata['uid'],$weiba_id);
			if($sf_admin||$sf_supadmin)
			{
				$sf_supadmin_user=$this->is_supadmin($post_uid,$weiba_id);
				if(!$sf_supadmin_user)
				{
					 //查询用户封禁状态
					 unset($map);
					$map['userid']=$post_uid;
					$map['weiba_id']=$article['weiba_id'];
					$map['status']=1;
					$us=M('weiba_bbs_users')->where($map)->find();
					if($us==null)
					 {
						$map['cuserid']=$userdata['uid'];
						$map['cdate']=time();
						M('weiba_bbs_users')->add($map);
					 }
					$data['ret']=1;
					$data['errmsg']='封禁用户成功!';
				}
				else
				{
					$data['ret']=0;
					$data['errmsg']='缺乏权限!';
				}
			}
			else
			{
				$data['ret']=0;
				$data['errmsg']='缺乏权限!';
			}
			$weiba_log['to_id']=$post_uid;
		}
		else if($event_type=='user_unlimit')
		{
			$islog=true;
			if($menu_type=='article')
			{
				$article=M('weiba_post')->where(array('id'=>$id))->find();
				$post_uid=$article['post_uid'];
			}
			else if($menu_type=='reply')
			{
				$article=M('weiba_reply')->where(array('reply_id'=>$id))->find();
				$post_uid=$article['uid'];
			}
			//判断是否可以封禁用户
			$sf_admin=$this->is_admin($userdata['uid'],$article['weiba_id']);
			$sf_supadmin=$this->is_supadmin($userdata['uid'],$article['weiba_id']);
			if($sf_admin||$sf_supadmin)
			{
				$sf_supadmin_user=$this->is_supadmin($post_uid,$article['weiba_id']);
				if(!$sf_supadmin_user)
				{
					 //查询用户封禁状态
					unset($map);
					$map['userid']=$post_uid;
					$map['weiba_id']=$article['weiba_id'];
					$map['status']=1;
					M('weiba_bbs_users')->where($map)->delete();
					$data['ret']=1;
					$data['errmsg']='取消封禁成功!';
				}
				else
				{
					$data['ret']=0;
					$data['errmsg']='缺乏权限!';
				}
			}
			else
			{
				$data['ret']=0;
				$data['errmsg']='缺乏权限!';
			}
			$weiba_log['to_id']=$post_uid;
		}
		else if($event_type=='article_click')
		{
			//点击量
			M('weiba_post')->where(array('id'=>$id))->setInc('read_count');
			//$tourl=DEFAULT_INDEX.'/html/p/'.$id.'.html';
			//$to_baidu=send_toBaidu($tourl);
			
			$data['ret']=1;
			$data['errmsg']='点击成功!';
			//$data['to_baidu']=$to_baidu;
		}
		else if($event_type=='weiba_click')
		{
			M('weiba')->where(array('id'=>$weiba_id))->setInc('click_count');
			$tourl=I('url','');
			$to_baidu=send_toBaidu($tourl);
			if($userdata['uid']>0&&$token!=null)
			{
				M('weiba_users')->where(array('uid'=>$userdata['uid'],'token'=>$token))->setInc('click_count');
				 
			}
			
			$data['ret']=1;
			$data['errmsg']='点击成功!';
			$data['to_baidu']=$to_baidu;
		}
		else if($event_type=='admin_add')
		{
			$islog=true;
			if(!$this->is_supadmin($userdata['uid'],$weiba_id))
			{
				$data['ret']=0;
				$data['errmsg']='用户缺乏权限!';
				 $this->ajaxReturn($data);
			}
			$uid=I('uid',0);
			$aduser=M('user')->where('uid='.$uid)->find();
			if($aduser==null)
			{
				$data['ret']=0; 
				$data['errmsg']='用户不存在!';
				 $this->ajaxReturn($data);
			}
			$admin_uid=explode(',',$this->bbs['admin_uid']);
			 if(is_array($admin_uid)){
				foreach($admin_uid as $id)
				{
					if(intval($id)==intval($uid))
					{
						$data['ret']=0;
						$data['errmsg']='用户已经是管理员，请勿重复添加!';
						$this->ajaxReturn($data);
						
					}
				}
			 }
			$admin_uid[]=$uid;
			$mapdata['admin_uid']=implode(',', $admin_uid);
			M('weiba')->where(array('id'=>$weiba_id))->save($mapdata); 
		//	dump($mapdata);
			$data['ret']=1;
			$data['errmsg']='添加成功!';
			$weiba_log['to_id']=$uid;
		}
		else if($event_type=='admin_del')
		{
			$islog=true;
			if(!$this->is_supadmin($userdata['uid'],$weiba_id))
			{
				$data['ret']=0;
				$data['errmsg']='用户缺乏权限!';
				 $this->ajaxReturn($data);
			}
			$uid=I('uid',0);
			$aduser=M('user')->where('uid='.$uid)->find();
			if($aduser==null)
			{
				$data['ret']=0; 
				$data['errmsg']='用户不存在!';
				 $this->ajaxReturn($data);
			}
			$admin_uid=explode(',',$this->bbs['admin_uid']);
			 if(is_array($admin_uid)){
				$new_admin;
				foreach($admin_uid as $id)
				{	
					if(intval($id)!=intval($uid))
					{
						$new_admin[]=$id;
					}
					 
				}
			 }
			 $mapdata['admin_uid']=implode(',', $new_admin);
			M('weiba')->where(array('id'=>$weiba_id))->save($mapdata); 
			$data['ret']=1;
			$data['errmsg']='删除成功!';
			$weiba_log['to_id']=$uid; 
			//$this->ajaxReturn($data);
			
		}
		else if($event_type=='blank_add')
		{
			$islog=true;
			if(!$this->is_supadmin($userdata['uid'],$weiba_id)&&!$this->is_admin($userdata['uid'],$weiba_id))
			{
				$data['ret']=0;
				$data['errmsg']='用户缺乏权限!';
				$this->ajaxReturn($data);
			}
			$uid=I('uid',0);
			$data['weiba_id']=$weiba_id;
			$data['userid']=$uid;
			$data['status']=1;
			$data['cuserid']=$userdata['uid'];
			$data['cdate']=time();
			M('weiba_bbs_users')->add($data);
			$data['ret']=1;
			$data['errmsg']='添加成功!';
			$weiba_log['to_id']=$uid; 
			
		}
		else if($event_type=='blank_del')
		{
			$islog=true;
			if(!$this->is_supadmin($userdata['uid'],$weiba_id)&&!$this->is_admin($userdata['uid'],$weiba_id))
			{
				$data['ret']=0;
				$data['errmsg']='用户缺乏权限!';
				 $this->ajaxReturn($data);
			}
			$uid=I('uid',0);
			$map['userid']=$uid;
			M('weiba_bbs_users')->where($map)->delete();
			$data['ret']=1;
			$data['errmsg']='删除成功!';
			$weiba_log['to_id']=$uid; 
		}
		else if($event_type=='bbs_shenhe')
		{
			$islog=true;
			if(!$this->is_supadmin($userdata['uid'],$weiba_id))
			{
				$data['ret']=0;
				$data['errmsg']='用户缺乏权限!';
				 $this->ajaxReturn($data);
			}
			$data['is_shenhe']=-1;
			M('weiba')->where(array('id'=>$weiba_id))->save($data);
			$data['ret']=1;
			$data['errmsg']='开启成功!';
			$weiba_log['weiba_id']=$weiba_id; 
		}
		else if($event_type=='bbs_unshenhe') 
		{
			$islog=true;
			if(!$this->is_supadmin($userdata['uid'],$weiba_id))
			{
				$data['ret']=0;
				$data['errmsg']='用户缺乏权限!';
				 $this->ajaxReturn($data);
			}
			$data['is_shenhe']=0;
			M('weiba')->where(array('id'=>$weiba_id))->save($data);
			$data['ret']=1;
			$data['errmsg']='关闭成功!';
			$weiba_log['weiba_id']=$weiba_id; 
		}
		else if($event_type=='singin')
		{
			$uid=$userdata['uid'];
			//$token='gh_140d5cf76662';
			$url=DEFAULT_FILE.'/index.php?s=/addon/SingIn/Wap/SingIn/uid/'.$uid.'/token/'.$token;
			$data=http_get($url);
			$data=json_decode($data);
		}
		else if($event_type=='checksingin')
		{
			
		}
	 
		if($islog)
		{
			//$weiba_log['content']=$data['ret'].':'.$data['errmsg'];
			//weiba_log_add($weiba_log);
			addLog($userdata['uid'],$event_type.'|'.$menu_type,$weiba_log,$data['ret'].':'.$data['errmsg']);
		}
		
		$this->ajaxReturn($data);
		
	}
}