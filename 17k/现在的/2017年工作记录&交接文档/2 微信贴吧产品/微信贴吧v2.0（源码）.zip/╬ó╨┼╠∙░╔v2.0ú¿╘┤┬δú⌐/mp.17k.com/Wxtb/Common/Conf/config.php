<?php
return array(
	//'配置项'=>'配置值'
	'API_URI'=>'http://mp.authorcrm.com/api/?',
		URL_MODEL => 2,
	'__PUBLIC__'=>__ROOT__ . '/Public',
	'__STATIC__'=>__ROOT__ . '/Public/Static',
	'__QQLOGIN__'=>__ROOT__ . '/Public/Static/qqConnect/login/oauth/index.php',
	'DATA_AUTH_KEY' => 'Vsj?AN-i;9ST3>4RE}5`f*+Xtv{ep]l,hy:#wWx=', // 默认数据加密KEY
	// 数据库配置
        'DB_TYPE'   => 'mysql', // 数据库类型
        'DB_HOST'   => '60.205.160.18', // 服务器地址
        'DB_NAME'   => 'xhw_17k', // 数据库名
        'DB_USER'   => 'root', // 用户名
        'DB_PWD'    => '`f*+Xtv',  // 密码  
        'DB_PORT'   => '3306', // 端口
        'DB_PREFIX' => 'yys_', // 数据库表前缀
		'DB_PARAMS' => array (
				\PDO::ATTR_CASE => \PDO::CASE_NATURAL 
		),
	'HTML_CACHE_ON'=>true,
	'HTML_CACHE_RULES'=>array(
		'index:index'=>array('{$_SERVER.REQUEST_URI|md5}',20),
		'index:content'=>array('{$_SERVER.REQUEST_URI|md5}',10)
	),
	'DB_SQL_BUILD_CACHE' => true,
	'DB_SQL_BUILD_LENGTH' => 20,
	'DATA_CACHE_TIME'=>20,
);